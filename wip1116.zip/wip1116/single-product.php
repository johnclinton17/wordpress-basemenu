<?php

/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */



get_header(); ?>



	<div id="primary" class="container-fluid">

		<main id="main" class="site-main" role="main">



		<?php

		// Start the loop.

		while ( have_posts() ) : the_post();

		?>



<!-- content for portfolio begin -->



<article>

<?php 
    $contenttwo="_brand_contenttwo_value_key";  
?>
 <!--my custom code --> 
<div class="port-banner container" style="display:block;margin-top:81px;">
<div class="col-md-6" style="text-align: center;">
 <?php the_post_thumbnail(); ?>
 </div>
 <div class="col-md-6">  
    <div class="banner-center ">
    <h2 class="portfolioname"> <?php the_title(); ?> </h2>
  
    <p class="portfolio-work-about portfolio-contenttwo amount"><!--<h3>Price</h3>--><?php echo get_post_meta($post->ID, $contenttwo, true); ?></p>
    <p class="enquery-margin"><a href="#" class="product-equiery">ENQUIRY</a></p>
    <p><?php the_content(); ?></p>
    </div>  
</div>
</div>


 <!--my custom code ends here--> 
  
</div>




<div class="container">


<div>
<div class="section-margin">
  <h2>related post</h2>
  <?php

$related = get_posts( array( 'category__in' => wp_get_post_categories($post->ID), 'numberposts' => 4,'post_type' => 'product', 'post__not_in' => array($post->ID) ) );
if( $related ) foreach( $related as $post ) {
setup_postdata($post); ?>
        <div class="col-md-3">
        <?php  the_post_thumbnail(); ?>
        <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></a>
        </div>

<?php }
wp_reset_postdata(); ?>
</div>
</div>

</div>



</article>



<!-- content for portfolio end -->



		<?php

		// End the loop.

		endwhile;

		?>



		</main><!-- .site-main -->

	</div><!-- .content-area -->



<?php get_footer(); ?>