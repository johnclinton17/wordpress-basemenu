<?php

/*
 *  Template Name: Teams
*/

get_header(); ?>

<!-- team -->

<header class="entry-header">

</header><!-- .entry-header -->
<div class="container">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
  <div class="row team-description">
    <div class="col-md-12">
      <div class="team-description-content "> 
        <?php the_content(); ?>
      </div>
    </div>
  </div>
<?php
 endwhile;
 endif;
?> 
</div>
<div class="container">
<div class="team-template">

<!-- custom post for team -->
<?php
  // WP_Query arguments
  $args = array (

    'post_type' => 'userportfolio',

    'order'     => 'ASC',

  );
  // The Query
  $query = new WP_Query( $args );
  // The Loop
  if ( $query->have_posts() ) {
    while ( $query->have_posts() ) {
      $query->the_post();
?>
    <div class="col-md-4">
    <div class="team-service-wrapper ">
  	<div class="demo-3">
        <figure>
    		<div class="team-image-wrapper">
          		<?php the_post_thumbnail('portfolio-thumb'); ?>
          	</div>
			
        </figure>

		   <div class="three-box-body">
		        <div class="member-name">
		          <?php echo '<h3>' . get_the_title() . '</h3>'; ?>
		          <?php
			//custom cat display
		              $terms = get_the_terms($post->ID, 'position' );
		                if ($terms && ! is_wp_error($terms)) :
		                  $term_slugs_arr = array();
		                  foreach ($terms as $term) {
		                  echo '<h6 class="member-position">'. $term->name .'</h6>';
		                  }
		                endif;
		          //custom cat display
		          ?>
		        </div> 
	        	<div class="about-member ">
	          		<p><?php the_content(); ?></p>
	        	</div>
		   </div>
		  </div>
</div>
</div>

  <!-- four-box 1 end -->

<?php
}
} else {
  // no posts found
  echo "<h1>boom no content team page </h1>";

}
// Restore original Post Data

wp_reset_postdata();?>
<div class="clearfix"></div>
<!-- service end -->
</div>
</div>
<?php get_footer(); ?>