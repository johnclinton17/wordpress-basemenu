<?php
/**
 * Footer For wip Theme.
 */
?>

<?php wp_footer(); ?>

<footer>
<div class="container">
<div class="conatiner col-md-12">
	<div class="footer-left col-md-6">
		<p>All Rights Reserved. &copy;2016. Rillusion.</p>
	</div>

	<div class="footer-right col-md-6">
		<p>User Experience By <a href="http://www.rillusion.com" target="_blank">Rillusion</a></p>
	</div>

</div>
</div>
</footer>

<!--jquery script-->
<script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>

<!--bootstrap js script-->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

<!--homepage carousal script-->
<script type="text/javascript">
jQuery(document).ready(function($) {
    $('.carousel').carousel({
  		interval: 5000	
  	})
});
</script>
<!--fancybox script-->
<script type="text/javascript" src="http://fancyapps.com/fancybox/source/jquery.fancybox.pack.js?v=2.1.5"></script>

<script type="text/javascript">
jQuery(document).ready(function(){
    jQuery("a.fancybox, .gallery-item .gallery-icon a").attr('rel','fancybox-gallery').fancybox({
        'enableEscapeButton' : 'true',
        'showCloseButton' : 'true',
	'fitToView' : 'true',
        'nextClick' : 'true'
    });
});
</script>
</body>
</html>
