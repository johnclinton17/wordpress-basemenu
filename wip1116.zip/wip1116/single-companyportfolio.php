<?php

/**
 * The template for displaying all single posts and attachments
 */
get_header(); ?>
	<div id="primary" class="container-fluid  margin-bottom">
		<main id="main" class="site-main" role="main">
		<?php
		// Start the loop.
		while ( have_posts() ) : the_post();
		?>
<!-- content for portfolio begin -->
<article>


<div class="portfolio-inner-content" style="background: <?php echo get_post_meta($post->ID, $color, true); ?> ">

 <!--my custom code --> 
<div class="port-banner" style="display:block;text-align:center;margin-top:81px;">
    <?php the_post_thumbnail(); ?>   
    <div class="banner-center">
    <h4 class="portfolioname"> <?php the_title(); ?> </h4>
    </div>  
</div>
 <!--my custom code ends here--> 

</div>
<div class="container">
    <div class="portfolio-inner-image">
    	<p><?php the_content(); ?></p>
    </div>
</div>

</article>

<!-- content for portfolio end -->
		<?php
		// End the loop.
		endwhile;
		?>
		</main><!-- .site-main -->
	</div><!-- .content-area -->
<?php get_footer(); ?>