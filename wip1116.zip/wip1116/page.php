<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package wip
 */

get_header(); ?>
<div class="container">
	<!--col-md-12-->
  <div class="col-md-8">
  		<?php while ( have_posts() ) : the_post(); ?>      
       <div class="blog blog-sec-margin  blog-sidebar-bg">
            <div class="blog">
              <!--thumbnail-->
              	<a href="<?php echo get_permalink(); ?>">
       				     <?php the_post_thumbnail(); ?>                               		
  				      </a> 
  			<!--title-->	
                <div class="post-data">
  					          <a href="<?php echo get_permalink(); ?>" class="blog-title"><?php the_title(); ?></a>      
                </div>
              <!--excerpt content-->                              
                     <p class="blog-excerpt">
          				     <?php the_excerpt(10); ?>
    				         </p>          
            </div><!--blog section end here-->	
              <?php
                if ( comments_open() || get_comments_number() ) :
                comments_template();
                endif;
              ?>
        </div>
           <?php endwhile;  ?>       
  </div><!--blog body end here-->      
  <div class="col-md-4"><!--blog side bar start here-->
    <div class="blog-sec-margin blog-sidebar-bg blog-sidebar-pad">
           <?php get_sidebar();?>
    </div>
  </div><!--blog side bar end here-->
</div><!--container end-->
<?php get_footer(); ?>