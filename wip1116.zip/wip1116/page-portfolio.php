<?php
/*
 *  Template Name: Portfolio
 *
 */
get_header(); ?>

<!-- Portfolio -->

<div class="container" style="margin-top: 54px;">

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

  <div class="row four-content-1">

    <div class="col-md-12">

      <div class="four-box-title"> 

        <?php the_content(); ?>

      </div>

    </div>

  </div>

<?php

 endwhile;

 endif;

?> 


<!-- custom post for team -->

<?php

  // WP_Query arguments

  $args = array (

    'post_type' => 'companyportfolio',

    'order'     => 'date',

  );



  // The Query

  $query = new WP_Query( $args );



  // The Loop

  if ( $query->have_posts() ) {

    while ( $query->have_posts() ) {

      $query->the_post();

?>



    <div class="col-md-3 " id="">

    <div class="portfolio-wrapper">

    <a href="<?php the_permalink(); ?>">

      <!--<div class="portfolio-image">

       <?php the_post_thumbnail( 'category-thumb', array('class' => 'img-responsive') ); ?>

      </div>-->

  <div class="portfolio-image">

  <?php $name = get_post_meta($post->ID, 'ExternalUrl', true);

if( $name ) { ?>

<a href="<?php echo $name; ?>"><?php the_post_thumbnail('category-thumb', array('class' => 'img-responsive')); ?></a>

<?php } else {

the_post_thumbnail();

} ?>

  </div>  

      <div class="three-box-body">

        <div class="portfolio-company">

          <?php echo '<h4>' . get_the_title() . '</h4>'; ?>



          <?php

              //custom cat display

              $terms = get_the_terms($post->ID, 'work' );

                if ($terms && ! is_wp_error($terms)) :

                  $term_slugs_arr = array();

                  foreach ($terms as $term) {

                    if($term->term_id != '41') { // the term ID you want to exclude

                       echo '<p class="portfolio-type">'. $term->name .'</p>';

                    }

                  }

                endif;

          //custom cat display

          ?>

        </div>

    </div>

    </a>

    </div>

    </div>



  <!-- four-box 1 end -->





<?php

}

} else {

  // no posts found

  echo "<h1>boom no content team page </h1>";

}



// Restore original Post Data

wp_reset_postdata();

?>

</div>



<div class="clearfix"></div>
<!-- service end -->
<?php get_footer(); ?>