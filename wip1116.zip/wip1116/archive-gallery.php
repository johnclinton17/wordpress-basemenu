<?php
/**
 * The template for displaying archive pages
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * If you'd like to further customize these archive views, you may create a
 * new template file for each one. For example, tag.php (Tag archives),
 * category.php (Category archives), author.php (Author archives), etc.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>
<div class="container">
	<!--col-md-12-->
	<div class="col-md-12">
  <div class="section-margin">
		<?php while ( have_posts() ) : the_post(); ?>
            
            <div class="col-md-4">
            <div class="blog">
            <!--thumbnail-->
            	<a href="<?php echo get_permalink(); ?>">
           				<?php the_post_thumbnail(); ?>                               		
      				</a> 
			       <!--title-->	
                <div class="post-data">
	         				<a href="<?php echo get_permalink(); ?>" class="blog-title"><?php the_title(); ?></a>     
                </div>    
                                     
            </div>             
            </div>	
       	</div>
         <?php endwhile;  ?>   
         
        

	</div>
	<!--col-md-8-->

	

</div>






<?php get_footer(); ?>


