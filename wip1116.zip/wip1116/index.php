<?php 
/*
 * Main Template File.
 */
get_header(); ?>

<div class="container">
	<!--col-md-12-->
	<div class="col-md-12">
		<?php while ( have_posts() ) : the_post(); ?>
            
            <div class="col-md-12">
            <div class="blog">
            <!--thumbnail-->
            	<a href="<?php echo get_permalink(); ?>">
     				<?php the_post_thumbnail(); ?>                               		
				</a> 
			<!--title-->	
                <div class="post-data">
					<a href="<?php echo get_permalink(); ?>" class="blog-title"><?php the_title(); ?></a>      
                </div>
            <!--excerpt content-->                              
                   <p class="blog-excerpt">
        				<?php the_excerpt(10); ?>
  				   </p>          
            </div>	
       	</div>
         <?php endwhile;  ?>   
         
        
<?php the_posts_pagination(); ?> 
	</div>
	<!--col-md-8-->

	

</div>






<?php get_footer(); ?>
