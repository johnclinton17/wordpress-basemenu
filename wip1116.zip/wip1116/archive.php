<?php
/**
 * The template for displaying archive pages
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * If you'd like to further customize these archive views, you may create a
 * new template file for each one. For example, tag.php (Tag archives),
 * category.php (Category archives), author.php (Author archives), etc.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>
<div class="container">
  	<!--col-md-12-->
  <div class="col-md-8">
  		<?php while ( have_posts() ) : the_post(); ?>
            <div class="blog blog-sec-margin  blog-sidebar-bg">
                <!--thumbnail-->
                	<a href="<?php echo get_permalink(); ?>">
         				   <?php the_post_thumbnail(); ?>                               		
    				      </a> 
    			<!--title-->
                <div class="post-content-padd">	
                    <div class="post-data">
                          <h2>
          					          <a href="<?php echo get_permalink(); ?>" class="blog-title"><?php the_title(); ?></a>
                          </h2>      
                    </div>
                      <!--excerpt content-->                              
                    <p class="blog-excerpt">
                  			<?php the_excerpt(10); ?>
            				</p>
               </div>                  
            </div>	
           <?php endwhile;  ?>   
           <?php pagination_nav(); ?>

  </div><!--blog body end here-->     
  <div class="col-md-4"><!--blog side bar start here-->
    <div class="blog-sec-margin blog-sidebar-bg blog-sidebar-pad">
    <?php get_sidebar();?>
    </div>
  </div><!--blog side bar end here-->
  	<!--col-md-8-->
</div><!--container end-->
<?php get_footer(); ?>


