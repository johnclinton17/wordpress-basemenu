<?php
/*
 *  Template Name: Products
 *
 */
get_header(); ?>

<!-- Portfolio -->

<div class="container" style="margin-top: 54px;">
<div class="col-md-8">

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

  <div class="row four-content-1">

    <div class="col-md-12">

      <div class="four-box-title"> 

        <?php the_content(); ?>

      </div>

    </div>

  </div>

<?php

 endwhile;

 endif;

?> 


<!-- custom post for team -->

<?php

  // WP_Query arguments

  $args = array (

    'post_type' => 'product',

    'order'     => 'date',

  );



  // The Query

  $query = new WP_Query( $args );



  // The Loop

  if ( $query->have_posts() ) {

    while ( $query->have_posts() ) {

      $query->the_post();

?>



    <div class="col-md-3 " id="">

    <div class="portfolio-wrapper">

    <a href="<?php the_permalink(); ?>">

     

  <div class="portfolio-image">

    <a href="<?php echo get_permalink(); ?>">
                  <?php the_post_thumbnail(); ?>                                  
    </a> 
  </div>  

      <div class="three-box-body">

        <div class="portfolio-company">

          <?php echo '<h4>' . get_the_title() . '</h4>'; ?>
          


         

        </div>

    </div>

    </a>

    </div>

    </div>



  <!-- four-box 1 end -->





<?php

}

} else {

  // no posts found

  echo "<h1>boom no content team page </h1>";

}



// Restore original Post Data

wp_reset_postdata();

?>

<div class="clearfix"></div>
</div>
<div class="col-md-4"><!--blog side bar start here-->
    <div class="blog-sec-margin blog-sidebar-bg blog-sidebar-pad">
    <?php get_sidebar();?>
    </div>
  </div><!--blog side bar end here-->
</div>





<!-- service end -->
<?php get_footer(); ?>