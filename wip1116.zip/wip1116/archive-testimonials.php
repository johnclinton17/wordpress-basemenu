<?php
/**
 * The template for displaying all testimonials single posts.
 *
 *
 */get_header(); ?>

<?php if (have_posts()) : ?>
<?php while (have_posts()) : the_post(); ?>
<div class="testimonial-wrap">
   <?php the_post_thumbnail('thumbnail', array('class' => 'client-photo')); ?>
     <div class="post-excerpt">
          <?php echo the_content(); ?>
      </div>
      <?php $client_name = get_post_meta(get_the_ID(), 'client_name', true);
      if (!empty($client_name)):
          ?>
          <div class="client_name">
          <?php echo $client_name; ?>
          </div>
      <?php endif; ?>
      <?php $company = get_post_meta(get_the_ID(), 'company', true);
      if (!empty($company)):
          ?>
          <div class="company">
          <?php echo $company; ?>
          </div>
      <?php endif; ?>
    </div>
<?php endwhile; ?>
<?php endif; ?>



<?php get_footer(); ?>