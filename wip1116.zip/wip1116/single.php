<?php
/**
 * The template for displaying all single posts.
 *
 *
 */

get_header(); ?>
<div class="container">
  <div class="col-md-8">
    <div class="blog-sec-margin blog-sidebar-bg">
    	<div id="primary" class="content-area">
    		<main id="main" class="site-main" role="main">
            <?php while ( have_posts() ) : the_post(); ?>
             <div  id="post-<?php the_ID(); ?>" <?php post_class(); ?>>          
          			<div class="blog">
                     <!--thumbnail-->
                      	<a href="<?php echo get_permalink(); ?>">
               				    <?php the_post_thumbnail(); ?>                               		
          				      </a> 
          			<!--title-->	
                       <div class="post-content-padd">  
                          <div class="post-data">
                              <h2>
              					       <a href="<?php echo get_permalink(); ?>" class="blog-title"><?php the_title(); ?></a>  
                              </h2>   
                          </div>
                      <!--excerpt content-->                              
                              <p class="blog-excerpt">
                  				      <?php the_content(); ?>
            				          </p>
                        </div>              
                </div>
                      <div class="post-content-padd">
                          <?php // If comments are open or we have at least one comment, load up the comment template.
                           if ( comments_open() || get_comments_number() ) :
                               comments_template();
                           endif;
                          ?>
                      </div>  
              </div>	
             <?php endwhile;  ?>   

<?php pagination_nav(); ?>
<?php next_posts_link(); ?>
<?php previous_posts_link(); ?>

    		</main><!-- #main -->
    	</div><!-- #primary -->
    </div>
  </div><!--blog body end here-->
  <div class="col-md-4"><!--blog side bar start here-->
      <div class="blog-sec-margin blog-sidebar-bg blog-sidebar-pad">
      <?php get_sidebar();?>
      </div>
  </div><!--blog side bar end here-->
</div><!--container end-->
<?php get_footer(); ?>
