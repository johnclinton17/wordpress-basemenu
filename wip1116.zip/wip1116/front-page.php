<?php get_header(); ?>

	<div class="slider">
		<div id="myCarousel" class="carousel slide">
		 <div class="carousel-inner">
			  <?php 
			   $the_query = new WP_Query(array(
			    'category_name' => 'Home Slider', 
			    'posts_per_page' => 1 
			    )); 
			   while ( $the_query->have_posts() ) : 
			   $the_query->the_post();
			  ?>
			   <div class="item active">
				    <?php the_post_thumbnail();?>
				    <div class="carousel-caption">
				     <h4><?php the_title();?></h4>
				     <p><?php the_excerpt();?></p>
				    </div>
			   </div><!-- item active -->
			  <?php 
			   endwhile; 
			   wp_reset_postdata();
			  ?>
			  <?php 
			   $the_query = new WP_Query(array(
			    'category_name' => 'Home Slider', 
			    'posts_per_page' => 5, 
			    'offset' => 1 
			    )); 
			   while ( $the_query->have_posts() ) : 
			   $the_query->the_post();
			  ?>
			   <div class="item">
				    <?php the_post_thumbnail();?>
				    <div class="carousel-caption">
				     <h4><?php the_title();?></h4>
				     <p><?php the_excerpt();?></p>
				    </div>
			   </div><!-- item -->
			  <?php endwhile; 
			   wp_reset_postdata();
			  ?>
		 </div><!-- carousel-inner -->
		 <a class="left carousel-control banner" href="#myCarousel" data-slide="prev">‹</a>
		 <a class="right carousel-control banner" href="#myCarousel" data-slide="next">›</a>
		</div><!-- #myCarousel -->
	</div><!--slider ends here-->

<!--testimonials starts here-->
<div class="blog-sidebar-bg">
	<div class="testimonials-container container">
	<div class="section-margin">
	<h2 class="text-center">Testimonials</h2>
		<div id="myCarousel1" class="carousel slide">
		 <div class="carousel-inner">
		  <?php 
		   $the_query = new WP_Query(array(
		    'post_type' => 'testimonials',
		    'posts_per_page' => 1 
		    )); 
		   while ( $the_query->have_posts() ) : 
		   $the_query->the_post();
		  ?>
		   <div class="item active">

		    <?php the_post_thumbnail('thumbnail', array('class' => 'client-photo')); ?>
		    <div class="carousel-caption">
		     <?php the_content(); ?>
		     <?php $client_name = get_post_meta(get_the_ID(), 'client_name', true);
		            if (!empty($client_name)):
		                ?>
		                <p class="client_name">
		                <?php echo $client_name; ?>
		                </p>
		            <?php endif; ?>
		            <?php $company = get_post_meta(get_the_ID(), 'company', true);
		            if (!empty($company)):
		                ?>
		                <p class="company">
		                <?php echo $company; ?>
		                </p>
		            <?php endif; ?>
		    </div>
		  
		   </div><!-- item active -->
		  <?php 
		   endwhile; 
		   wp_reset_postdata();
		  ?>
		  <?php 
		   $the_query = new WP_Query(array(
		    'post_type' => 'testimonials', 
		    'posts_per_page' => 5, 
		    'offset' => 1 
		    )); 
		   while ( $the_query->have_posts() ) : 
		   $the_query->the_post();
		  ?>
		   <div class="item">
		    <?php the_post_thumbnail('thumbnail', array('class' => 'client-photo')); ?>
		    <div class="carousel-caption">
		     <?php the_content(); ?>
		     <?php $client_name = get_post_meta(get_the_ID(), 'client_name', true);
		            if (!empty($client_name)):
		                ?>
		                <p class="client_name">
		                <?php echo $client_name; ?>
		                </p>
		            <?php endif; ?>
		            <?php $company = get_post_meta(get_the_ID(), 'company', true);
		            if (!empty($company)):
		                ?>
		                <p class="company">
		                <?php echo $company; ?>
		                </p>
		            <?php endif; ?>
		    </div>
		   </div><!-- item -->
			  <?php 
			   endwhile; 
			   wp_reset_postdata();
			  ?>
			 </div><!-- carousel-inner -->
			 <a class="left carousel-control" href="#myCarousel1" data-slide="prev">‹</a>
			 <a class="right carousel-control" href="#myCarousel1" data-slide="next">›</a>
			</div><!-- #myCarousel -->
			</div>
		</div><!--testimonials ends here-->
</div>
	<!--recent blog post-->
	<div class="container">
	<div class="section-margin">
	<div class="recent-post ">
			<h2 class="text-center">Recent Post</h2>
				<?php
		$args = array( 'numberposts' => 3 );
		$lastposts = get_posts( $args );
		foreach($lastposts as $post) : setup_postdata($post); ?>
		<div class="col-md-4 ophtha-box frontbox-blog ">
		<a href="<?php echo get_permalink(); ?>">
		     <?php the_post_thumbnail('portfolio-thumb'); ?>                              
		</a>
		<div class="blog-sidebar-bg post-content-padd"> 
		  <h4 class="box-title fronttitle-blog"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
		  <p class="content-smallbox front-blog">
		        <?php the_excerpt(10); ?>
		  </p>
		 </div> 
		</div>  
		<?php endforeach; ?>

	</div>
	</div>	
	</div>
	<!--recent blog post ends here-->




<?php get_footer(); ?>