<?php
/*
 *  Template Name: gallery
 *
 */
get_header(); ?>
 
<div id="content-galerie">
 
<!-- custom post for team -->

<?php
  // WP_Query arguments
  $args = array (
    'post_type' => 'gallery',
    'order'     => 'date',
  );
// The Query
  $query = new WP_Query( $args );
  // The Loop
  if ( $query->have_posts() ) {
    while ( $query->have_posts() ) {
      $query->the_post();
?>
    <div class="col-md-3 " id="">
    <div class="portfolio-wrapper">
    <a href="<?php the_permalink(); ?>">
  <div class="portfolio-image">
	<?php the_post_thumbnail(); ?>  
  </div>  
      <div class="three-box-body">
        <div class="portfolio-company">
          <?php echo '<h4>' . get_the_title() . '</h4>'; ?>
          
        </div>
    </div>
    </a>
    </div>
    </div>
  <!-- four-box 1 end -->
<?php
}
} else {
  // no posts found
  echo "<h1>boom no content team page </h1>";
}
// Restore original Post Data
wp_reset_postdata();
?>
</div>
<div class="clearfix"></div>

<?php get_footer(); ?>