
<?php
/*
 * Theme function file.
 */// This theme uses wp_nav_menu() in two locations.

	register_nav_menus( array(

		'primary' => __( 'Primary Menu', 'wip' ),

		'social'  => __( 'Social Links Menu', 'wip' ),

	) );
//john theme css and script call to folder start here


//calling scripts an style
function wip_scripts() {
	// Add Genericons font, used in the main stylesheet.
	wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/css/bootstrap.css');
	wp_enqueue_style( 'menu', get_template_directory_uri() . '/css/menu.css');
	wp_enqueue_style( 'home', get_template_directory_uri() . '/css/home.css');
	//wp_enqueue_style( 'fancybox', get_template_directory_uri() . '/css/jquery.fancybox-1.3.4.css');

	// Load our main stylesheet.
	wp_enqueue_style( 'wip-style', get_stylesheet_uri() );



	//wp_enqueue_script('fancyboxjs',get_template_directory_uri().'/js/fancybox.js');


}

add_action( 'wp_enqueue_scripts', 'wip_scripts' );

//john theme css and script call to folder end here





//john them read more button function call to start here
//for calling excerpt
function wpdocs_excerpt_more( $more ) {
    return '<a class="read-more" href="'.get_the_permalink().'" rel="nofollow">Read More...</a>';
}
add_filter( 'excerpt_more', 'wpdocs_excerpt_more' );
//john theme read more button function call to start here



//john theme post thumnail image function start here
//for calling featured image
add_theme_support( 'post-thumbnails' );
//john theme post thumnail image function end here


//john theme side bar wedgest function start here
//sidebar call
function wip_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'wip' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'wip' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
}
add_action( 'widgets_init', 'wip_widgets_init' );
//john theme sidebar wedgest functionend here

//post format

add_theme_support( 'post-formats', array(

			'aside',

			'image',

			'video',

			'quote',

			'link',

			'gallery',

			'status',

			'audio',

			'chat',

		) );




//john theme testimonial function start here
//adding testimonials custom post

function create_posttype() {
  $args = array(
    'labels' => array(
      'name' => __('Testimonials'),
      'singular_name' => __('Testimonials'),
      'all_items' => __('All Testimonials'),
      'add_new_item' => __('Add New Testimonial'),
      'edit_item' => __('Edit Testimonial'),
      'view_item' => __('View Testimonial')
    ),
    'public' => true,
    'has_archive' => true,
    'rewrite' => array('slug' => 'testimonials'),
    'show_ui' => true,
    'show_in_menu' => true,
    'show_in_nav_menus' => true,
    'capability_type' => 'page',
    'supports' => array('title', 'editor', 'thumbnail'),
    'exclude_from_search' => true,
    'menu_position' => 80,
    'has_archive' => true,
    'menu_icon' => 'dashicons-format-status'
    );
  register_post_type('testimonials', $args);
}
add_action( 'init', 'create_posttype');

function my_add_meta_box(){
    add_meta_box( 'testimonial-details', 'Testimonial Details', 'my_meta_box_cb', 'testimonials', 'normal', 'default');
}
function my_meta_box_cb($post){
    $values = get_post_custom( $post->ID );
    $client_name = isset( $values['client_name'] ) ? esc_attr( $values['client_name'][0] ) : "";
    $company = isset( $values['company'] ) ? esc_attr( $values['company'][0] ) : "";
    wp_nonce_field( 'testimonial_details_nonce_action', 'testimonial_details_nonce' );
    $html = '';
    $html .= '<label>Client Name</label>';
    $html .= '<input type="text" name="client_name" id="client_name" style="margin-top:15px; margin-left:9px; margin-bottom:10px;" value="'. $client_name .'" /><br/>';
    $html .= '<label>Company</label>';
    $html .= '<input type="text" name="company" id="company" style="margin-left:25px; margin-bottom:15px;" value="'. $company .'" />';
    echo $html;
}
function my_save_meta_box($post_id){
    // Bail if we're doing an auto save
    if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
 
    // if our nonce isn't there, or we can't verify it, bail
    if( !isset( $_POST['testimonial_details_nonce'] ) || !wp_verify_nonce( $_POST['testimonial_details_nonce'], 'testimonial_details_nonce_action' ) ) return;
 
    // if our current user can't edit this post, bail
    if( !current_user_can( 'edit_post' ) ) return;
 
    if(isset( $_POST['client_name'] ) )
        update_post_meta( $post_id, 'client_name', $_POST['client_name']);
 
    if(isset( $_POST['company'] ) )
        update_post_meta( $post_id, 'company', $_POST['company']);
}
add_action( 'add_meta_boxes', 'my_add_meta_box' );
add_action( 'save_post', 'my_save_meta_box' );
//john theme testimonial function end here





//john theme team function start here
//feature image portfolio
add_image_size( 'portfolio-thumb', 360, 300 );

//team custom post 
function userportfolio() {

	$labels = array(
		'name'                  => _x( 'Teams', 'Post Type General Name', 'base' ),
		'singular_name'         => _x( 'Team', 'Post Type Singular Name', 'base' ),
		'menu_name'             => __( 'Role', 'base' ),
		'name_admin_bar'        => __( 'Team', 'base' ),
		'archives'              => __( 'Member Archives', 'base' ),
		'parent_item_colon'     => __( 'Parent Member:', 'base' ),
		'all_items'             => __( 'All Member', 'base' ),
		'add_new_item'          => __( 'Add New Member', 'base' ),
		'add_new'               => __( 'Add New Member', 'base' ),
		'new_item'              => __( 'New Member', 'base' ),
		'edit_item'             => __( 'Edit Member', 'base' ),
		'update_item'           => __( 'Update Member', 'base' ),
		'view_item'             => __( 'View Member', 'base' ),
		'search_items'          => __( 'Search Member', 'base' ),
		'not_found'             => __( 'Not found, try to find in office', 'base' ),
		'not_found_in_trash'    => __( 'Not found in Trash, because they were human ', 'base' ),
		'featured_image'        => __( 'Selfie Image', 'base' ),
		'set_featured_image'    => __( 'Set Selfie image', 'base' ),
		'remove_featured_image' => __( 'Remove Selfie image', 'base' ),
		'use_featured_image'    => __( 'Use as Selfie image', 'base' ),
		'insert_into_item'      => __( 'Insert into member', 'base' ),
		'uploaded_to_this_item' => __( 'Uploaded to this member', 'base' ),
		'items_list'            => __( 'Member list', 'base' ),
		'items_list_navigation' => __( 'Member list navigation', 'base' ),
		'filter_items_list'     => __( 'Filter member list', 'base' ),
	);
	$args = array(
		'label'                 => __( 'User Portfolio', 'base' ),
		'description'           => __( 'User in rillusion', 'base' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'excerpt', 'thumbnail', 'trackbacks', 'revisions', 'custom-fields', 'page-attributes', ),
		'taxonomies'            => array( 'userportfolio' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'             => 'dashicons-groups',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => true,
		'publicly_queryable'    => true,
		'capability_type'       => 'post',
	);
	register_post_type( 'userportfolio', $args );
	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => true,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,
			
	);
	register_taxonomy( 'position', 'userportfolio', $args );

}
add_action( 'init', 'userportfolio', 0 );
//john theme team function end here



//john theme portfolio function start here
//portfolio
// Register Custom Post Type
function companyportfolio() {

	$labels = array(
		'name'                  => _x( 'Portfolios', 'Post Type General Name', 'base' ),
		'singular_name'         => _x( 'Portfolio', 'Post Type Singular Name', 'base' ),
		'menu_name'             => __( 'Portfolio', 'base' ),
		'name_admin_bar'        => __( 'Portfolio', 'base' ),
		'archives'              => __( 'Portfolio Archives', 'base' ),
		'parent_item_colon'     => __( 'Parent Portfolio:', 'base' ),
		'all_items'             => __( 'All Portfolio', 'base' ),
		'add_new_item'          => __( 'Add New Portfolio', 'base' ),
		'add_new'               => __( 'Add New Portfolio', 'base' ),
		'new_item'              => __( 'New Portfolio', 'base' ),
		'edit_item'             => __( 'Edit Portfolio', 'base' ),
		'update_item'           => __( 'Update Portfolio', 'base' ),
		'view_item'             => __( 'View Portfolio', 'base' ),
		'search_items'          => __( 'Search Portfolio', 'base' ),
		'not_found'             => __( 'Not found, we will build for you', 'base' ),
		'not_found_in_trash'    => __( 'Not found in Trash, because we where trying to make it', 'base' ),
		'featured_image'        => __( 'Feature Image', 'base' ),
		'set_featured_image'    => __( 'Set Feature image', 'base' ),
		'remove_featured_image' => __( 'Remove Feature image', 'base' ),
		'use_featured_image'    => __( 'Use as Feature image', 'base' ),
		'insert_into_item'      => __( 'Insert into Portfolio', 'base' ),
		'uploaded_to_this_item' => __( 'Uploaded to Portfolio', 'base' ),
		'items_list'            => __( 'Portfolio list', 'base' ),
		'items_list_navigation' => __( 'Portfolio list navigation', 'base' ),
		'filter_items_list'     => __( 'Filter Portfolio list', 'base' ),
	);
	$args = array(
		'label'                 => __( 'User Portfolio', 'base' ),
		'description'           => __( 'User in rillusion', 'base' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'excerpt', 'thumbnail', 'trackbacks', 'revisions', 'custom-fields', 'page-attributes', ),
		'taxonomies'            => array( 'deal' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'             => 'dashicons-video-alt2',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => true,
		'publicly_queryable'    => true,
		//'query_var' => 'portfoli',
		//'rewrite' => array( 'slug' => 'portfolio' ),
		'capability_type'       => 'post',
	);
	register_post_type( 'companyportfolio', $args );
	


	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => true,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,
	);
	register_taxonomy( 'work', 'companyportfolio', $args );
	

// url re-wright for getting template file
	flush_rewrite_rules( false );
//test

}
add_action( 'init', 'companyportfolio', 0 );
//john theme portfolio function  here




//john theme gallery function start here
//photogallery
 /**
Custom Post Type Galerie
 */


function gallery() {

	$labels = array(
		'name'                  => _x( 'gallerys', 'Post Type General Name', 'base' ),
		'singular_name'         => _x( 'gallery', 'Post Type Singular Name', 'base' ),
		'menu_name'             => __( 'gallery', 'base' ),
		'name_admin_bar'        => __( 'gallery', 'base' ),
		'archives'              => __( 'gallery Archives', 'base' ),
		'parent_item_colon'     => __( 'Parent gallery:', 'base' ),
		'all_items'             => __( 'All gallery', 'base' ),
		'add_new_item'          => __( 'Add New gallery', 'base' ),
		'add_new'               => __( 'Add New gallery', 'base' ),
		'new_item'              => __( 'New gallery', 'base' ),
		'edit_item'             => __( 'Edit gallery', 'base' ),
		'update_item'           => __( 'Update gallery', 'base' ),
		'view_item'             => __( 'View gallery', 'base' ),
		'search_items'          => __( 'Search gallery', 'base' ),
		'not_found'             => __( 'Not found, we will build for you', 'base' ),
		'not_found_in_trash'    => __( 'Not found in Trash, because we where trying to make it', 'base' ),
		'featured_image'        => __( 'Feature Image', 'base' ),
		'set_featured_image'    => __( 'Set Feature image', 'base' ),
		'remove_featured_image' => __( 'Remove Feature image', 'base' ),
		'use_featured_image'    => __( 'Use as Feature image', 'base' ),
		'insert_into_item'      => __( 'Insert into gallery', 'base' ),
		'uploaded_to_this_item' => __( 'Uploaded to gallery', 'base' ),
		'items_list'            => __( 'gallery list', 'base' ),
		'items_list_navigation' => __( 'gallery list navigation', 'base' ),
		'filter_items_list'     => __( 'Filter gallery list', 'base' ),
	);
	$args = array(
		'label'                 => __( 'User gallery', 'base' ),
		'description'           => __( 'User in rillusion', 'base' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'excerpt', 'thumbnail', 'trackbacks', 'revisions', 'custom-fields', 'page-attributes', ),
		'taxonomies'            => array( 'deal' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'             => 'dashicons-format-gallery',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => true,
		'publicly_queryable'    => true,
		//'query_var' => 'portfoli',
		//'rewrite' => array( 'slug' => 'portfolio' ),
		'capability_type'       => 'post',
	);
	register_post_type( 'gallery', $args );
	


	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => true,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,
	);
	register_taxonomy( 'work', 'gallery', $args );
	

// url re-wright for getting template file
	flush_rewrite_rules( false );
//test

}
add_action( 'init', 'gallery', 0 );
//john theme portfolio function end here
//pagination


//john theme pagination function start here
function pagination_nav() {
    global $wp_query;
 
    if ( $wp_query->max_num_pages > 1 ) { ?>
        <nav class="pagination" role="navigation">
            <div class="nav-previous"><?php next_posts_link( '&larr; Older posts' ); ?></div>
            <div class="nav-next"><?php previous_posts_link( 'Newer posts &rarr;' ); ?></div>
        </nav>
<?php }
}
//john theme pagination function end here




//john theme production function start here
//products
function my_custom_post_product() {
  $labels = array(
    'name'               => _x( 'Products', 'post type general name' ),
    'singular_name'      => _x( 'Product', 'post type singular name' ),
    'add_new'            => _x( 'Add New', 'book' ),
    'add_new_item'       => __( 'Add New Product' ),
    'edit_item'          => __( 'Edit Product' ),
    'new_item'           => __( 'New Product' ),
    'all_items'          => __( 'All Products' ),
    'view_item'          => __( 'View Product' ),
    'search_items'       => __( 'Search Products' ),
    'not_found'          => __( 'No products found' ),
    'not_found_in_trash' => __( 'No products found in the Trash' ), 
    'parent_item_colon'  => '',
    'menu_name'          => 'Products'
  );
  $args = array(
    'labels'        => $labels,
    'description'   => 'Holds our products and product specific data',
    'public'        => true,
    'menu_position' => 5,
    'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'comments' ),
    'has_archive'   => true,
  );
  register_post_type( 'product', $args ); 
}
add_action( 'init', 'my_custom_post_product' );

function my_taxonomies_product() {
  $labels = array(
    'name'              => _x( 'Product Categories', 'taxonomy general name' ),
    'singular_name'     => _x( 'Product Category', 'taxonomy singular name' ),
    'search_items'      => __( 'Search Product Categories' ),
    'all_items'         => __( 'All Product Categories' ),
    'parent_item'       => __( 'Parent Product Category' ),
    'parent_item_colon' => __( 'Parent Product Category:' ),
    'edit_item'         => __( 'Edit Product Category' ), 
    'update_item'       => __( 'Update Product Category' ),
    'add_new_item'      => __( 'Add New Product Category' ),
    'new_item_name'     => __( 'New Product Category' ),
    'menu_name'         => __( 'Product Categories' ),
  );
  $args = array(
    'labels' => $labels,
    'hierarchical' => true,
  );
  register_taxonomy( 'product_category', 'product', $args );
}
add_action( 'init', 'my_taxonomies_product', 0 );



/**
 * Adds a box to the main column on the Post and Page edit screens.
 */
function brand_contenttwo_add_meta_box() {

//	$screens = array( 'post', 'page' ); remove page
	$screens = array( 'product' );

	foreach ( $screens as $screen ) {

		add_meta_box(
			'brand_contenttwo_sectionid',
			__( 'Price', 'base' ),
			'brand_contenttwo_meta_box_callback',
			$screen
		);
	}
}
add_action( 'add_meta_boxes', 'brand_contenttwo_add_meta_box' );




/**
 * Prints the box content.
 * 
 * @param WP_Post $post The object for the current post/page.
 */
function brand_contenttwo_meta_box_callback( $post ) {

	// Add a nonce field so we can check for it later.
	wp_nonce_field( 'brand_contenttwo_save_meta_box_data', 'brand_contenttwo_meta_box_nonce' );

	/*
	 * Use get_post_meta() to retrieve an existing value
	 * from the database and use the value for the form.
	 */
	$value = get_post_meta( $post->ID, '_brand_contenttwo_value_key', true );

	echo '<label for="brand_contenttwo_new_field">';
	_e( '', 'base' );
	echo '</label> ';
	echo '<textarea name="brand_contenttwo_new_field" value=" id="brand_contenttwo_new_field" cols="92" rows="5" /> ' . esc_attr( $value ) . '</textarea>';
}

/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 */
function brand_contenttwo_save_meta_box_data( $post_id ) {

	/*
	 * We need to verify this came from our screen and with proper authorization,
	 * because the save_post action can be triggered at other times.
	 */

	// Check if our nonce is set.
	if ( ! isset( $_POST['brand_contenttwo_meta_box_nonce'] ) ) {
		return;
	}

	// Verify that the nonce is valid.
	if ( ! wp_verify_nonce( $_POST['brand_contenttwo_meta_box_nonce'], 'brand_contenttwo_save_meta_box_data' ) ) {
		return;
	}

	// If this is an autosave, our form has not been submitted, so we don't want to do anything.
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	// Check the user's permissions.
	if ( isset( $_POST['post_type'] ) && 'page' == $_POST['post_type'] ) {

		if ( ! current_user_can( 'edit_page', $post_id ) ) {
			return;
		}

	} else {

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
	}

	/* OK, it's safe for us to save the data now. */
	
	// Make sure that it is set.
	if ( ! isset( $_POST['brand_contenttwo_new_field'] ) ) {
		return;
	}

	// Sanitize user input.
	$my_data = sanitize_text_field( $_POST['brand_contenttwo_new_field'] );

	// Update the meta field in the database.
	update_post_meta( $post_id, '_brand_contenttwo_value_key', $my_data );
}
add_action( 'save_post', 'brand_contenttwo_save_meta_box_data' );


?>
<!--john theme product function end here-->