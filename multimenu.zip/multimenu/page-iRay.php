<?php
/*
 * Template Name: iRay page
 */
$deserve_options = get_option('deserve_theme_options');

get_header();
?>

<div class="container-fluid">
  <a data-toggle="modal" data-target="#myModal">
    <div class="float-demo" >

      <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/live-demo.png" alt="LIVE DEMO" >
      <span class="float-style">Request For Live Demo</span>
     </div> 
  </a>
    <!--section1 ends-->
    <div class="section-1 background-height background-heightnew" >

      <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/iRay/Banner.png" alt="OpthLIVE HMIS" class="img-responsive">
      <div class="carousel-caption static-ban">
      <h3>Go Digital With a Simple iRAY System</h3>   
      <button class="slider-but"><a href="<?php echo esc_url(home_url('')); ?>/contact-us">Contact us for More Info</a></button>
    </div>
</div>


<!--section1 ends-->

<!--section 2-->

<div class="section-2" >
  <div class="container">
    <div class="ophtha-sextion1 opthalive-section">
            <h2 class="section-title">iRay</h2>
            <span class="border-green"></span>  

            <p class="content-box">
            <span class="line-1">Digital radiography has quite a lot of benefits compared to its conventional counterpart.</span>
            <span class="line-2">It makes real sense to upgrade from an analog version because of the following reasons</span>    
      </p>
    </div>

   <div class="OpthLIVE-wrapper1 "> 
    <div class="col-md-3 ophtha-box opthLIve-box iray-box">
      <div class="opthlive-imagewrapper">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/iRay/portability.png" alt="OpthLIVE TELE" class="img-responsive">
      </div> 
       <div class="box-content"> 
        <h6 class="box-title">Portability & storage</h6>
        
       </div><!--box content-->
    </div><!--col-md-3-->

    <div class="col-md-3 ophtha-box opthLIve-box iray-box">
      <div class="opthlive-imagewrapper">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/iRay/easier-workflow.png" alt="OpthLIVE CLINICS" class="img-responsive">
      </div> 
       <div class="box-content"> 
        <h6 class="box-title">Easier Workflow Management</h6>
        
       </div><!--box content-->
    </div><!--col-md-3-->  

     <div class="col-md-3 ophtha-box opthLIve-box iray-box">
      <div class="opthlive-imagewrapper">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/iRay/lower-ownership.png" alt="OpthLIVE HMIS" class="img-responsive">
      </div> 
       <div class="box-content"> 
        <h6 class="box-title">Lower Cost of Ownership</h6>
        
       </div><!--box content-->
    </div><!--col-md-3--> 

    <div class="col-md-3 ophtha-box opthLIve-box iray-box">
      <div class="opthlive-imagewrapper">
           <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/iRay/use-existing-modality.png" alt="OpthLIVE HMIS" class="img-responsive">
      </div>     
           <div class="box-content"> 
            <h6 class="box-title">Use your Existing Modality</h6>
            
           </div><!--box content-->
        </div><!--col-md-3-->

        <div class="col-md-3 ophtha-box opthLIve-box iray-box">
      <div class="opthlive-imagewrapper">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/iRay/access-radiologists.png" alt="OpthLIVE TELE" class="img-responsive">
      </div>
       <div class="box-content"> 
        <h6 class="box-title">Access Radiologists Online</h6>
        
       </div><!--box content-->
    </div><!--col-md-3-->

    <div class="col-md-3 ophtha-box opthLIve-box  iray-box">
      <div class="opthlive-imagewrapper">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/iRay/filmless-reporting.png" alt="OpthLIVE CLINICS" class="img-responsive">
      </div> 
       <div class="box-content"> 
        <h6 class="box-title">Filmless  Reporting</h6>
        
       </div><!--box content-->
    </div><!--col-md-3-->  

     <div class="col-md-3 ophtha-box opthLIve-box iray-box">
      <div class="opthlive-imagewrapper">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/iRay/pay-per-report.png" alt="OpthLIVE HMIS" class="img-responsive">
      </div> 
       <div class="box-content"> 
        <h6 class="box-title">Pay per Report if Opted Radlive Series</h6>
        
       </div><!--box content-->
    </div><!--col-md-3--> 
<div class="col-md-12 iray-wrapper">
    <p class="content-box">
            <span class="line-1">Ray lets you to convert your X-ray films to diagnostic quality DICOM images with an advanced DICOM viewer and full PACS integration capabilities. iRay i</span>
            <span class="line-2">the most comprehensive and cost-effective alternative to expensive X-ray digitizers.</span>
            <span class="line-3">I-ray is available separately or as a part of the RadLIVE series.</span>
    </p>
</div>    
  </div><!--wrapper-->

</div><!--container-->

</div>

<!--section 2 ends-->
<!--section3-->
<div class="section-3" >
  <div class="container-fluid benefits-wrapper">
  <div class="container">
    
    <div class="ophtha-sextion1">
        <h2 class="section-title">Features</h2>
        <span class="border-green"></span>  
    </div>


    <div class="OPHTHALIVEWRAPPER wow slideInLeft" data-wow-offset="0" data-wow-duration="1.5s">
    
        <div class="col-md-3 ophtha-box irayfeture-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/iRay/powerful-film-acquisition.png" alt="OpthLIVE TELE" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Powerful Film Acquisition</h6>
        <p class="content-smallbox">
           Includes pre-processing corrections and diagnostic quality digitisation.
        </p>
        
       </div><!--box content-->
    </div><!--col-md-4-->

        <div class="col-md-3 ophtha-box irayfeture-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/iRay/dicom-viewer.png" alt="OpthLIVE TELE" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Integrated DICOM Viewer </h6>
        <p class="content-smallbox">
           DICOM print and CD/DVD writing options, multi monitor and multi display options.
        </p>
        
       </div><!--box content-->
    </div><!--col-md-4-->

       <div class="col-md-3 ophtha-box irayfeture-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/iRay/post-processing-suite.png" alt="OpthLIVE TELE" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Post Processing Suite</h6>
        <p class="content-smallbox">
           Image processing, annotations and measurements, overlays and much more.
        </p>
        
       </div><!--box content-->
    </div><!--col-md-4-->

       <div class="col-md-3 ophtha-box irayfeture-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/iRay/flexible-reporting.png" alt="OpthLIVE TELE" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">PACS Integration</h6>
        <p class="content-smallbox">
           Works with any third party PACS. Study distribution and archival on CD/DVD.
        </p>
        
       </div><!--box content-->
    </div><!--col-md-4-->

    <div class="col-md-3 ophtha-box irayfeture-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/iRay/flexible-reporting.png" alt="OpthLIVE TELE" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Flexible Reporting</h6>
        <p class="content-smallbox">
           Integrated reporting engine for quick reporting, multimedia reports and customizable templates.
        </p>
        
       </div><!--box content-->
    </div><!--col-md-4-->

    <div class="col-md-3 ophtha-box irayfeture-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/iRay/free-software-update.png" alt="OpthLIVE TELE" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Free Software Updates</h6>
        <p class="content-smallbox">
           
        </p>
        
       </div><!--box content-->
    </div><!--col-md-4-->





  </div><!--content wrapper-->
  </div><!--container--> 
  </div><!--wrapper-->
</div> <!--SECTION3-->

<div class="clearfix"></div>

<!--section 4-->

<div class="clearfix"></div>


<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header popform">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Request for Live Demo</h4>
      </div>
      <div class="modal-body">
        <?php echo do_shortcode( '[contact-form-7 id="85" title="Live Demo"]' ); ?>
      </div>
      <div class="modal-footer">

      </div>
    </div>
  </div>
</div>
</div>
<!--modal-->


</div><!--container-fluid-->
<?php get_footer(); ?>
