<?php
/*
 * Template Name: Consulting page
 */
$deserve_options = get_option('deserve_theme_options');

get_header();
?>

<div class="container-fluid">
  <a data-toggle="modal" data-target="#myModal">
    <div class="float-demo" >

      <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/live-demo.png" alt="LIVE DEMO" >
      <span class="float-style">Request For Live Demo</span>
     </div> 
  </a>
    <!--section1 ends-->
<div class="section-1 background-height " >

 <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/consulting-banner.jpg" alt="OpthLIVE HMIS" class="img-responsive">
<div class="carousel-caption static-ban">
        <h3>Consulting</h3>
       <button class="slider-but"><a href="<?php echo esc_url(home_url('')); ?>/contact-us">Contact us for More Info</a></button>
      </div>
</div>
<!--section1 ends-->
<!--section2-->
<div class="section-2 page-bottom" >


    <div class="ophtha-sextion1">
            <h2 class="section-title">Transform your world of healthcare imaging.</h2>
            <span class="border-green"></span>  
    </div>

   <div class="container"> 
    
    <p class="content-box">
            <span class="line-1">Specialist skills to integrate across your healthcare IT platform, in DICOM, clinical imaging, communications, networking, encryption and security.</span>
            <span class="line-2">Today’s complex healthcare environment is punctuated with a myriad of applications that don’t talk to each other ,</span>
            <span class="line-3"> geographically distributed facilities and users, and unprecedented reform and regulatory compliance. </span>
            <span class="line-1">Improving care while reducing its cost is the key.Pellucid has a track record of delivering tailor </span>
            <span class="line-2">made solutions and applications that serve your unique requirements.</span>
    </p>
   </div><!--container-->
    
   
</div> <!--SECTION2-->

<div class="clearfix"></div>

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header popform">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Request for Live Demo</h4>
      </div>
      <div class="modal-body">
        <?php echo do_shortcode( '[contact-form-7 id="85" title="Live Demo"]' ); ?>
      </div>
      <div class="modal-footer">

      </div>
    </div>
  </div>
</div>
</div>
<!--modal-->



</div><!--container-fluid-->
<?php get_footer(); ?>
