<?php
/*
 * Main Sidebar File.
 */
?>
 <div class="col-md-12  blog-detail main-sidebar">

<?php if ( is_active_sidebar( 'sidebar-1' ) ) : dynamic_sidebar( 'sidebar-1' ); endif; ?>

</div>
 
