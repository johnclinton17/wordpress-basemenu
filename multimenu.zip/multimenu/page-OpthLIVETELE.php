<?php
/*
 * Template Name: OpthLIVE TELE page
 */
$deserve_options = get_option('deserve_theme_options');

get_header();
?>

<div class="container-fluid">
  <a data-toggle="modal" data-target="#myModal">
    <div class="float-demo" >

      <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/live-demo.png" alt="LIVE DEMO" >
      <span class="float-style">Request For Live Demo</span>
     </div> 
  </a> 
    <!--section1 ends-->
<div class="section-1 background-height background-heightnew" >
<img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-TELE/Banner.png" alt="LIVE DEMO" >
<div class="carousel-caption static-ban">
        <h3>Empowering Your Vision</h3>
        <button class="slider-but"><a href="<?php echo esc_url(home_url('')); ?>/contact-us">Contact us for More Info</a></button>
      </div>
</div> 



<!--section1 ends-->

<!--section 2-->

<div class="section-2" >
  <div class="container">
    <div class="ophtha-sextion1 opthalive-section">
            <h2 class="section-title">OpthLIVE TELE</h2>
            <span class="border-green"></span>  

            <p class="content-box">
            <span class="line-1">This is a flagship product in the space of preventive screening for avoidable blindness. Vision is most often lost or dramatically</span>
            <span class="line-2">impaired, because there is no effective treatment, hence prevention is the best possible strategy. It is the most preferred </span>
            <span class="line-3">choice in the treatment of Diabetic Retinopathy, Age Related Macular Degeneration (AMD), Glaucoma besides other ailments</span>
            <span class="line-4">such as Cataract, Trachoma, Poor vision, etc.</span>
        
      </p>
    </div>

   <div class="OpthLIVE-wrapper1 "> 
    <div class="col-md-3 ophtha-box opthLIve-box opthLIvetele-box">
      <div class="opthlive-imagewrapper">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-TELE/computer-aided-diagnosis.png" alt="OpthLIVE TELE" class="img-responsive">
      </div> 
       <div class="box-content"> 
        <h6 class="box-title">Computer Aided Diagnostics</h6>
        <p class="content-smallbox">
        <span class="boxline-1">Allows paramedics & nurses</span>    
        <span class="boxline-2">to perform screening.</span>    
           
        </p>
       </div><!--box content-->
    </div><!--col-md-3-->

    <div class="col-md-3 ophtha-box opthLIve-box opthLIvetele-box">
      <div class="opthlive-imagewrapper">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-TELE/feature-grading.png" alt="OpthLIVE CLINICS" class="img-responsive">
      </div> 
       <div class="box-content"> 
        <h6 class="box-title">Feature Based Grading</h6>
        <p class="content-smallbox">
        <span class="boxline-1">Allows the detection of symptoms</span>    
        <span class="boxline-2">even before the occurrence of the</span>    
        <span class="boxline-3">disease, this is the gold standard</span>    
        <span class="boxline-4">in preventive screening.</span>    
        </p>
       </div><!--box content-->
    </div><!--col-md-3-->  

     <div class="col-md-3 ophtha-box opthLIve-box opthLIvetele-box">
      <div class="opthlive-imagewrapper">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-TELE/ability-to-extract-info.png" alt="OpthLIVE HMIS" class="img-responsive">
      </div> 
       <div class="box-content"> 
        <h6 class="box-title">Ability to Extract Information for<br>all Types Ophthalmology Vendors<br>&amp; Equipment </h6>
        <p class="content-smallbox">
        <span class="boxline-1">This is a unique feature which</span>    
        <span class="boxline-2">most vendors cannot perform.</span>    
       
        </p>
       </div><!--box content-->
    </div><!--col-md-3--> 

    <div class="col-md-3 ophtha-box opthLIve-box opthLIvetele-box">
      <div class="opthlive-imagewrapper">
           <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-TELE/single-patient-jacket.png" alt="OpthLIVE HMIS" class="img-responsive">
      </div>     
           <div class="box-content"> 
            <h6 class="box-title">Single Patient Jacket</h6>
            <p class="content-smallbox">
            <span class="boxline-1">Empowering patient mobility across</span>    
            <span class="boxline-2">multi-chains and location.</span>    
              
            </p>
           </div><!--box content-->
        </div><!--col-md-3-->

        <div class="col-md-3 ophtha-box opthLIve-box opthLIvetele-box">
      <div class="opthlive-imagewrapper">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-TELE/integrated-care.png" alt="OpthLIVE TELE" class="img-responsive">
      </div>
       <div class="box-content"> 
        <h6 class="box-title">Integrated Care</h6>
        <p class="content-smallbox">
        <span class="boxline-1">Allows monitoring, surveillance and</span>    
        <span class="boxline-2">treatment at the primary care level,</span>     
        <span class="boxline-3">thereby cutting down load to big</span>     
        <span class="boxline-4">tertiary hospitals.</span>     
        </p>
       </div><!--box content-->
    </div><!--col-md-3-->

    <div class="col-md-3 ophtha-box opthLIve-box opthLIvetele-box">
      <div class="opthlive-imagewrapper">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-TELE/common-pathway-care.png" alt="OpthLIVE CLINICS" class="img-responsive">
      </div> 
       <div class="box-content"> 
        <h6 class="box-title">Common Pathway for Care</h6>
        <p class="content-smallbox">
        <span class="boxline-1">Standardize care aspects across</span>    
        <span class="boxline-2">Hospitals, with an aim to quantify</span>       
        <span class="boxline-3">cost of care, because if cost of</span>       
        <span class="boxline-4">care can be quantified, it can be</span>       
        <span class="boxline-5">reduced.</span>       
        </p>
       </div><!--box content-->
    </div><!--col-md-3-->  

     <div class="col-md-3 ophtha-box opthLIve-box opthLIvetele-box">
      <div class="opthlive-imagewrapper">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-TELE/intelligent-dashboard.png" alt="OpthLIVE HMIS" class="img-responsive">
      </div> 
       <div class="box-content"> 
        <h6 class="box-title">Detailed MIS and Intelligent<br>Dashboards</h6>
        <p class="content-smallbox">
        <span class="boxline-1">Provides customers with actionable</span>    
        <span class="boxline-2">intelligence to plan intervention</span>    
        <span class="boxline-3">strategies to prevent “avoidable”</span>    
        <span class="boxline-4">blindness.</span>    
        </p>
       </div><!--box content-->
    </div><!--col-md-3--> 


        <div class="col-md-3 ophtha-box opthLIve-box opthLIvetele-box">
          <div class="opthlive-imagewrapper">
           <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-TELE/open-standards.png" alt="OpthLIVE HMIS" class="img-responsive">
          </div> 
           <div class="box-content"> 
            <h6 class="box-title">Promotes Open Standards.</h6>
            <p class="content-smallbox">
            <span class="boxline-1">Compliant to DICOM, IHE and</span>    
            <span class="boxline-2">promotes open standards.</span>  
            </p>
           </div><!--box content-->
        </div><!--col-md-3-->

    
  </div><!--wrapper-->

</div><!--container-->

</div>

<!--section 2 ends-->
<!--section3-->
<div class="section-3" >
  <div class="container-fluid benefits-wrapper">
  <div class="container">
    
    <div class="ophtha-sextion1">
        <h2 class="section-title">Features</h2>
        <span class="border-green"></span>  
    </div>


    <div class="OPHTHALIVEWRAPPER">
    
        <div class="col-md-3 ophtha-box opthLIve-box opthLIvetele-box">
          <div class="opthlive-imagewrapper">
           <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-TELE/registration.png" alt="OpthLIVE HMIS" class="img-responsive">
          </div> 
           <div class="box-content"> 
            <h6 class="box-title">Registration</h6>
            <p class="content-smallbox">
            <span class="boxline-1">Capturing basic patient details such</span>    
            <span class="boxline-2">as name, age, gender, marital status,</span>  
            <span class="boxline-3">etc for registration.</span>  
            </p>
           </div><!--box content-->
        </div><!--col-md-3-->

        <div class="col-md-3 ophtha-box opthLIve-box opthLIvetele-box">
          <div class="opthlive-imagewrapper">
           <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-TELE/appointment.png" alt="OpthLIVE HMIS" class="img-responsive">
          </div> 
           <div class="box-content"> 
            <h6 class="box-title">Appointment & Scheduling</h6>
            <p class="content-smallbox">
            <span class="boxline-1">Scheduling patient appointment</span>    
            <span class="boxline-2">with healthcare professionals.</span>  
            </p>
           </div><!--box content-->
        </div><!--col-md-3-->

        <div class="col-md-3 ophtha-box opthLIve-box opthLIvetele-box">
          <div class="opthlive-imagewrapper">
           <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-TELE/billing-finance.png" alt="OpthLIVE HMIS" class="img-responsive">
          </div> 
           <div class="box-content"> 
            <h6 class="box-title">Billing and Finance</h6>
            <p class="content-smallbox">
            <span class="boxline-1">Multiple services & rate cards,</span>    
            <span class="boxline-2">multiple payment modes, Multi-</span>  
            <span class="boxline-3">currency mode, Discount policies,</span>  
            <span class="boxline-4">Insurance billing,  Invoice scheduling</span>  
            <span class="boxline-5">&amp; auto generation, Client payment</span>  
            <span class="boxline-6">tracker.</span>  
            </p>
           </div><!--box content-->
        </div><!--col-md-3-->

        <div class="col-md-3 ophtha-box opthLIve-box opthLIvetele-box">
          <div class="opthlive-imagewrapper">
           <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-TELE/image-acquisiton.png" alt="OpthLIVE HMIS" class="img-responsive">
          </div> 
           <div class="box-content"> 
            <h6 class="box-title">Automatic Image Acquisition</h6>
            <p class="content-smallbox">
            <span class="boxline-1">Capture directly from Fundus, OCT,</span>    
            <span class="boxline-2">B-Scans, store & handle it.</span>  
            </p>
           </div><!--box content-->
        </div><!--col-md-3-->

        <div class="col-md-3 ophtha-box opthLIve-box opthLIvetele-box">
          <div class="opthlive-imagewrapper">
           <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-TELE/diabetic.png" alt="OpthLIVE HMIS" class="img-responsive">
          </div> 
           <div class="box-content"> 
            <h6 class="box-title">Diabetic Retinopathy Screening</h6>
            <p class="content-smallbox">
            <span class="boxline-1">Automated DR screening with</span>    
            <span class="boxline-2">grading & arbitrating grading service.</span>  
            </p>
           </div><!--box content-->
        </div><!--col-md-3-->

        <div class="col-md-3 ophtha-box opthLIve-box opthLIvetele-box">
          <div class="opthlive-imagewrapper">
           <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-TELE/structured-reporting.png" alt="OpthLIVE HMIS" class="img-responsive">
          </div> 
           <div class="box-content"> 
            <h6 class="box-title">Structured Reporting</h6>
            <p class="content-smallbox">
            <span class="boxline-1">Custom design reporting, Client</span>    
            <span class="boxline-2">specific and centre wise reporting</span>  
            <span class="boxline-3">formats, Reporting in SI and</span>  
            <span class="boxline-4">conventional units, Summary and</span>  
            <span class="boxline-5">detail reporting per patient visit, </span>  
            <span class="boxline-6">Trends, charts and images.</span>  
            </p>
           </div><!--box content-->
        </div><!--col-md-3-->

        <div class="col-md-3 ophtha-box opthLIve-box opthLIvetele-box">
          <div class="opthlive-imagewrapper">
           <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-TELE/workflow-management.png" alt="OpthLIVE HMIS" class="img-responsive">
          </div> 
           <div class="box-content"> 
            <h6 class="box-title">Workflow Management</h6>
            <p class="content-smallbox">
            <span class="boxline-1">Built in EM | 360 Dashboards |</span>    
            <span class="boxline-2">Multi-Location support | Single</span>  
            <span class="boxline-3">Unified work list.</span>  
            </p>
           </div><!--box content-->
        </div><!--col-md-3-->

        <div class="col-md-3 ophtha-box opthLIve-box opthLIvetele-box">
          <div class="opthlive-imagewrapper">
           <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-TELE/auto-assign.png" alt="OpthLIVE HMIS" class="img-responsive">
          </div> 
           <div class="box-content"> 
            <h6 class="box-title">Auto Assign</h6>
            <p class="content-smallbox">
            <span class="boxline-1">Automated workload distribution</span>    
            <span class="boxline-2">algorithm.</span>  
            </p>
           </div><!--box content-->
        </div><!--col-md-3-->

        <div class="col-md-3 ophtha-box opthLIve-box opthLIvetele-box">
          <div class="opthlive-imagewrapper">
           <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-TELE/anytime.png" alt="OpthLIVE HMIS" class="img-responsive">
          </div> 
           <div class="box-content"> 
            <h6 class="box-title">Anytime, Anywhere Access</h6>
            <p class="content-smallbox">
            <span class="boxline-1">Mobile and Desktop support</span>    
          
            </p>
           </div><!--box content-->
        </div><!--col-md-3-->



  </div><!--content wrapper-->
  </div><!--container--> 
  </div><!--wrapper-->
</div> <!--SECTION3-->

<div class="clearfix"></div>

<!--section 4-->

<div class="section-4" >

    <div id="myCarousel" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
    <li data-target="#myCarousel" data-slide-to="3"></li>
 
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-TELE/Slider-Dashboard.png" alt="OpthLIVE-TELE">
  
    </div>
    <div class="item">
      <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-TELE/Dashboard-casesheet.png" alt="OpthLIVE CLINICS" alt="Chania">
    </div>

    <div class="item">
      <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-TELE/Dashboard-image-manipulation.png" alt="OpthLIVE-TELE">
  
    </div>

    <div class="item">
      <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-TELE/Dashboard-Report.png" alt="OpthLIVE-TELE">
  
    </div>
</div>


</div>

</div><!--section5-->
<!--section 4 ends-->
<div class="clearfix"></div>
<!--section5-->

<div class="section-5 " >
  <div class="download-banner">
    <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-TELE/Infograph-workflow.jpg" alt="LIVE DEMO" >
  </div>    
</div> 



<!--section5-->

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header popform">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Request for Live Demo</h4>
      </div>
      <div class="modal-body">
        <?php echo do_shortcode( '[contact-form-7 id="85" title="Live Demo"]' ); ?>
      </div>
      <div class="modal-footer">

      </div>
    </div>
  </div>
</div>
</div>
<!--modal-->


</div><!--container-fluid-->
<?php get_footer(); ?>
