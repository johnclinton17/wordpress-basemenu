<?php
/*
 * Template Name: News Room page
 */
$deserve_options = get_option('deserve_theme_options');

get_header();
?>

<div class="container-fluid">
 <a data-toggle="modal" data-target="#myModal">
    <div class="float-demo" >

      <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/live-demo.png" alt="LIVE DEMO" >
      <span class="float-style">Request For Live Demo</span>
     </div> 
  </a>
    <!--section1 ends-->
<div class="section-1 background-height" >
  <div class="download-banner">
    <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/newsroom/banner.png" alt="LIVE DEMO" >
  </div>    
</div> 



<!--section1 ends-->


<!--section 2-->

<div class="section-2">
  <div class="container  wow fadeInDown" >

            <!-- Nav tabs -->
       <div class="tab-header col-md-12">   
        <ul class="nav nav-tabs" role="tablist">
          <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Press Releases</a></li>
          <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Media Coverages</a></li>
        </ul>
       </div>
        
        <!-- Tab panes -->


        <div class="tab-body col-md-12">
        <div class="tab-content">
          <div role="tabpanel" class="tab-pane fade in active" id="home">
            
            <h4 class="tab-title">Press Releases</h4>

            <div class="team-wrapper"> 
    <div class="col-md-4 ophtha-box download">

     <div class="keynote">
        <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/newsroom/press-release.jpg" alt="Ophthalmology" class="img-responsive">
        <div class="keynote-desc">
          <p class="keynote-name">Pellucid Networks</p>
          <p class="keynote-bio"> <a href="" class="more">Download</a></p>
        </div>
    </div>
    </div><!--col-md-4-->
   

    <div class="col-md-4 ophtha-box download">
        <div class="keynote">
        <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/newsroom/press-release.jpg" alt="Ophthalmology" class="img-responsive">
        <div class="keynote-desc">
          <p class="keynote-name">Tele Imaging Healthcare</p>
          <p class="keynote-bio"> <a href="" class="more">Download</a></p>
        </div>
    </div>
    </div><!--col-md-4-->

    <div class="col-md-4 ophtha-box download">
        <div class="keynote">
        <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/newsroom/press-release.jpg" alt="Ophthalmology" class="img-responsive">
        <div class="keynote-desc">
          <p class="keynote-name">RadLIVE Tele Radiology</p>
          <p class="keynote-bio"> <a href="" class="more">Download</a></p>
        </div>
    </div>
    </div><!--col-md-4-->

    <div class="col-md-4 ophtha-box download">

     <div class="keynote">
        <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/newsroom/press-release.jpg" alt="Ophthalmology" class="img-responsive">
        <div class="keynote-desc">
        <p class="keynote-name">Mercatus Healthcare</p>
        <p class="keynote-bio"> <a href="" class="more">Download</a></p>
      </div>
    </div>
    </div><!--col-md-4-->
   

    <div class="col-md-4 ophtha-box download">

     <div class="keynote">
        <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/newsroom/press-release.jpg" alt="Ophthalmology" class="img-responsive">
        <div class="keynote-desc">
          <p class="keynote-name">ZapRad</p>
          <p class="keynote-bio"> <a href="" class="more">Download</a></p>
        </div>
    </div>
    </div><!--col-md-4-->

    <div class="col-md-4 ophtha-box download">
 
        <div class="keynote">
          <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/newsroom/press-release.jpg" alt="Ophthalmology" class="img-responsive">
          <div class="keynote-desc">
            <p class="keynote-name">Launch Of ZapRad</p>
            <p class="keynote-bio"> <a href="" class="more">Download</a></p>
          </div>
        </div>
    </div><!--col-md-4-->

    <div class="col-md-4 ophtha-box download">
 
        <div class="keynote">
          <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/newsroom/press-release.jpg" alt="Ophthalmology" class="img-responsive">
          <div class="keynote-desc">
            <p class="keynote-name">RadLIVE GO!</p>
            <p class="keynote-bio"> <a href="" class="more">Download</a></p>
          </div>
        </div>
    </div><!--col-md-4-->

    <div class="col-md-4 ophtha-box download">
 
        <div class="keynote">
          <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/newsroom/press-release.jpg" alt="Ophthalmology" class="img-responsive">
          <div class="keynote-desc">
            <p class="keynote-name">RadLive Terranova</p>
            <p class="keynote-bio"> <a href="" class="more">Download</a></p>
          </div>
        </div>
    </div><!--col-md-4-->

    <div class="col-md-4 ophtha-box download">
 
        <div class="keynote">
          <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/newsroom/press-release.jpg" alt="Ophthalmology" class="img-responsive">
          <div class="keynote-desc">
            <p class="keynote-name">launch of RadLive GO!</p>
            <p class="keynote-bio"> <a href="" class="more">Download</a></p>
          </div>
        </div>
    </div><!--col-md-4-->

    <div class="col-md-4 ophtha-box download">
 
        <div class="keynote">
          <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/newsroom/press-release.jpg" alt="Ophthalmology" class="img-responsive">
          <div class="keynote-desc">
            <p class="keynote-name">Mercatus Capital invests</p>
            <p class="keynote-bio"> <a href="" class="more">Download</a></p>
          </div>
        </div>
    </div><!--col-md-4-->

 
  </div><!--team wrapper-->  
            

          </div>

          <div role="tabpanel" class="tab-pane fade" id="profile">

            <h4 class="tab-title">Media Coverages</h4>
            <div class="team-wrapper">

    
    <div class="col-md-4 ophtha-box download">

     <div class="keynote">
        <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/newsroom/exoress-healthcare.png" alt="Ophthalmology" class="img-responsive">
        <div class="keynote-desc">
          <p class="keynote-name">Express Health Care</p>
          <p class="keynote-bio"> <a href="" class="more">Read</a></p>
        </div>
    </div>
    </div><!--col-md-4-->


    <div class="col-md-4 ophtha-box download">
      <div class="keynote">
          <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/newsroom/exoress-healthcare.png" alt="Ophthalmology" class="img-responsive">
          <div class="keynote-desc">
            <p class="keynote-name">Express Health Care</p>
            <p class="keynote-bio"> <a href="" class="more">Read</a></p>
          </div>
      </div>
    </div><!--col-md-4-->

    <div class="col-md-4 ophtha-box download">
      <div class="keynote">
          <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/newsroom/live-mint.png" alt="Ophthalmology" class="img-responsive">
          <div class="keynote-desc">
            <p class="keynote-name">livemint.com</p>
            <p class="keynote-bio"> <a href="" class="more">Download</a></p>
          </div>
      </div>
    </div><!--col-md-4-->

    <div class="col-md-4 ophtha-box download">
      <div class="keynote">
          <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/newsroom/your-story.png" alt="Ophthalmology" class="img-responsive">
          <div class="keynote-desc">
            <p class="keynote-name">Yourstory.in</p>
            <p class="keynote-bio"> <a href="" class="more">Download</a></p>
          </div>
      </div>
    </div><!--col-md-4-->

    <div class="col-md-4 ophtha-box download">
      <div class="keynote">
          <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/newsroom/the-hindu.png" alt="Ophthalmology" class="img-responsive">
          <div class="keynote-desc">
            <p class="keynote-name">The Hindu</p>
            <p class="keynote-bio"> <a href="" class="more">Download</a></p>
          </div>
      </div>
    </div><!--col-md-4-->

    <div class="col-md-4 ophtha-box download">
      <div class="keynote">
          <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/newsroom/cnbc.png" alt="Ophthalmology" class="img-responsive">
          <div class="keynote-desc">
            <p class="keynote-name">CNBC TV 18</p>
            <p class="keynote-bio"> <a href="" class="more">View</a></p>
          </div>
      </div>
    </div><!--col-md-4-->



    </div>
   </div><!--tabpane--> 
          </div><!--tab content-->
          
        </div><!--colmd-12-->
       </div> 
</div>





  </div><!--container-->
</div>
    

<!--section 2 ends-->

<!--section 2 ends-->

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header popform">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Request for Live Demo</h4>
      </div>
      <div class="modal-body">
        <?php echo do_shortcode( '[contact-form-7 id="85" title="Live Demo"]' ); ?>
      </div>
      <div class="modal-footer">

      </div>
    </div>
  </div>
</div>
</div>
<!--modal-->

</div><!--container-fluid-->
<?php get_footer(); ?>
