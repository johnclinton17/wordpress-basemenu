<?php
/*
 * Template Name: Download page
 */
$deserve_options = get_option('deserve_theme_options');

get_header();
?>

<div class="container-fluid">
 <a data-toggle="modal" data-target="#myModal">
    <div class="float-demo" >

      <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/live-demo.png" alt="LIVE DEMO" >
      <span class="float-style">Request For Live Demo</span>
     </div> 
  </a>
    <!--section1 ends-->
<div class="section-1 background-height" >
  <div class="download-banner">
    <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Downloads/banner.jpg" alt="LIVE DEMO" >
  </div>    
</div> 



<!--section1 ends-->


<!--section 2-->

<div class="section-2">
  <div class="container  wow fadeInDown" >
    <div class="ophtha-sextion1 opthalive-section">
            <h2 class="section-title">Marketing</h2>
            <span class="border-green"></span>  
    </div>

   <div class="team-wrapper"> 
    <div class="col-md-4 ophtha-box download">

     <div class="keynote">
        <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Downloads/iray.jpg" alt="Ophthalmology" class="img-responsive">
        <div class="keynote-desc">
          <p class="keynote-name">iRay</p>
          <p class="keynote-bio"> <a href="" class="more">Download</a></p>
        </div>
    </div>
    </div><!--col-md-4-->
   

    <div class="col-md-4 ophtha-box download">
        <div class="keynote">
        <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Downloads/aravind-eye-care.jpg" alt="Ophthalmology" class="img-responsive">
        <div class="keynote-desc">
          <p class="keynote-name">Aravind Eye  Care</p>
          <p class="keynote-bio"> <a href="" class="more">Download</a></p>
        </div>
    </div>
    </div><!--col-md-4-->

    <div class="col-md-4 ophtha-box download">
        <div class="keynote">
        <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Downloads/time-medical.jpg" alt="Ophthalmology" class="img-responsive">
        <div class="keynote-desc">
          <p class="keynote-name">Time Medical</p>
          <p class="keynote-bio"> <a href="" class="more">Download</a></p>
        </div>
    </div>
    </div><!--col-md-4-->

    <div class="col-md-4 ophtha-box download">

     <div class="keynote">
        <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Downloads/national-rural.jpg" alt="Ophthalmology" class="img-responsive">
        <div class="keynote-desc">
        <p class="keynote-name">National Rural Health Mission</p>
        <p class="keynote-bio"> <a href="" class="more">Download</a></p>
      </div>
    </div>
    </div><!--col-md-4-->
   

    <div class="col-md-4 ophtha-box download">

     <div class="keynote">
        <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Downloads/star-health-insurance.jpg" alt="Ophthalmology" class="img-responsive">
        <div class="keynote-desc">
          <p class="keynote-name">Star Health Insurance</p>
          <p class="keynote-bio"> <a href="" class="more">Download</a></p>
        </div>
    </div>
    </div><!--col-md-4-->

    <div class="col-md-4 ophtha-box download">
 
        <div class="keynote">
          <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Downloads/image-center.jpg" alt="Ophthalmology" class="img-responsive">
          <div class="keynote-desc">
            <p class="keynote-name">Imaging Center</p>
            <p class="keynote-bio"> <a href="" class="more">Download</a></p>
          </div>
        </div>
    </div><!--col-md-4-->

 
  </div><!--team wrapper-->  
</div><!--container-->   

</div>

<!--section 2 ends-->

<!--section 2 ends-->

<!--section3-->
<div class="section-3" >
<div class="container-fluid benefits-wrapper">

    <div class="ophtha-sextion1">
            <h2 class="section-title">Guides</h2>
            <span class="border-green"></span> 
    </div>        
    <div class="container">
      <div class="team-wrapper">

    
    <div class="col-md-4 ophtha-box download">

     <div class="keynote">
        <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Downloads/star-health-insurance.jpg" alt="Ophthalmology" class="img-responsive">
        <div class="keynote-desc">
          <p class="keynote-name">Client Product Requirement Form</p>
          <p class="keynote-bio"> <a href="" class="more">Download</a></p>
        </div>
    </div>
    </div><!--col-md-4-->


    <div class="col-md-4 ophtha-box download">
      <div class="keynote">
          <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Downloads/time-medical.jpg" alt="Ophthalmology" class="img-responsive">
          <div class="keynote-desc">
            <p class="keynote-name">TSP Client Requirement Form</p>
            <p class="keynote-bio"> <a href="" class="more">Download</a></p>
          </div>
      </div>

    </div><!--col-md-4-->

    </div>
   </div><!--container--> 
  </div>   
</div> <!--SECTION3-->

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header popform">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Request for Live Demo</h4>
      </div>
      <div class="modal-body">
        <?php echo do_shortcode( '[contact-form-7 id="85" title="Live Demo"]' ); ?>
      </div>
      <div class="modal-footer">

      </div>
    </div>
  </div>
</div>
</div>
<!--modal-->

</div><!--container-fluid-->
<?php get_footer(); ?>
