<?php
/*
 * Template Name: RadLIVE cloudPACS page
 */
$deserve_options = get_option('deserve_theme_options');

get_header();
?>

<div class="container-fluid">
  <a data-toggle="modal" data-target="#myModal">
    <div class="float-demo" >

      <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/live-demo.png" alt="LIVE DEMO" >
      <span class="float-style">Request For Live Demo</span>
     </div> 
  </a>
    <!--section1 ends-->
  <div class="section-1 background-height background-heightnew" >

      <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-cloudPACS/banner.png" alt="OpthLIVE HMIS" class="img-responsive">
      <div class="carousel-caption static-ban">
      <h3>Redefining radiology imaging</h3>   
      <button class="slider-but"><a href="<?php echo esc_url(home_url('')); ?>/contact-us">Contact us for More Info</a></button>
    </div>
  </div>
<!--section1 ends-->

<!--section 2-->

<div class="section-2" >
  <div class="container">
    <div class="ophtha-sextion1 opthalive-section">
            <h2 class="section-title">RadLIVE CloudPACS</h2>
            <span class="border-green"></span>  

            <p class="content-box">
            <span class="line-1">With RadLIVE cloud PACS  you will be able to integrate radiology groups, imaging centres, teleradiology services, hospitals </span>
            <span class="line-2">and clinics with radiologists by obtaining your own space in the cloud</span>    
            <span class="line-3">thus ensuring better security.</span>    
      </p>
    </div>

   <div class="OpthLIVE-wrapper1 "> 
    <div class="col-md-3 ophtha-box opthLIve-box iray-box">
      <div class="opthlive-imagewrapper">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-cloudPACS/vendor-neutral.png" alt="OpthLIVE TELE" class="img-responsive">
      </div> 
       <div class="box-content"> 
        <h6 class="box-title">Vendor Neutral Archive</h6>
        
       </div><!--box content-->
    </div><!--col-md-3-->

    <div class="col-md-3 ophtha-box opthLIve-box iray-box">
      <div class="opthlive-imagewrapper">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-cloudPACS/third-party-integration.png" alt="OpthLIVE CLINICS" class="img-responsive">
      </div> 
       <div class="box-content"> 
        <h6 class="box-title">Third Party Integration</h6>
        
       </div><!--box content-->
    </div><!--col-md-3-->  

     <div class="col-md-3 ophtha-box opthLIve-box iray-box">
      <div class="opthlive-imagewrapper">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-cloudPACS/wprkstation.png" alt="OpthLIVE HMIS" class="img-responsive">
      </div> 
       <div class="box-content"> 
        <h6 class="box-title">
        <span class="line-1">Powerful 3D Luminate workstation</span>
        <span class="line-2">with dynamic image streaming</span>
        <span class="line-3">Technology</span>
        </h6>
        
       </div><!--box content-->
    </div><!--col-md-3--> 

    <div class="col-md-3 ophtha-box opthLIve-box iray-box">
      <div class="opthlive-imagewrapper">
           <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-cloudPACS/precache-feature.png" alt="OpthLIVE HMIS" class="img-responsive">
      </div>     
           <div class="box-content"> 
            <h6 class="box-title">
            <span class="line-1">Pre cache feature that enables loading</span>
            <span class="line-2">of features before a radiologist logs in</span>
            </h6>
           </div><!--box content-->
        </div><!--col-md-3-->

        <div class="col-md-3 ophtha-box opthLIve-box iray-box">
      <div class="opthlive-imagewrapper">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-cloudPACS/priority-patients.png" alt="OpthLIVE TELE" class="img-responsive">
      </div>
       <div class="box-content"> 
        <h6 class="box-title">
          <span class="line-1">Prioritization of cases for each</span>
          <span class="line-2">radiologist based on clinical rules</span>
        </h6>
        
       </div><!--box content-->
    </div><!--col-md-3-->

    <div class="col-md-3 ophtha-box opthLIve-box  iray-box">
      <div class="opthlive-imagewrapper">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-cloudPACS/multisite-streaming.png" alt="OpthLIVE CLINICS" class="img-responsive">
      </div> 
       <div class="box-content"> 
        <h6 class="box-title">
          <span class="line-1">Multi site streaming &amp;</span>
          <span class="line-2">load balancing</span>
        </h6>
       </div><!--box content-->
    </div><!--col-md-3-->  

     <div class="col-md-3 ophtha-box opthLIve-box iray-box">
      <div class="opthlive-imagewrapper">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-cloudPACS/web-based.png" alt="OpthLIVE HMIS" class="img-responsive">
      </div> 
       <div class="box-content"> 
        <h6 class="box-title">Web Based</h6>
        
       </div><!--box content-->
    </div><!--col-md-3--> 

  </div><!--wrapper-->

</div><!--container-->

</div>

<!--section 2 ends-->

<!--section3-->
<div class="section-3" >
<div class="conatiner-fluid cloudpacs-wrapper">
    <div class="ophtha-sextion1">
            <h2 class="section-title"></h2>
           
    </div> 

   <div class="container">
    <div class="center-image"> 
    <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-cloudPACS/workflow.png" alt="OpthLIVE TELE" class="img-responsive">
   </div> 
   </div>

 </div>  
</div> <!--SECTION3-->

<!--section4-->
<div class="section-4" >
  <div class="container-fluid benefits-wrapper">
  <div class="container">
    
    <div class="ophtha-sextion1">
        <h2 class="section-title">Features</h2>
        <span class="border-green"></span>  
    </div>


    <div class="OPHTHALIVEWRAPPER wow slideInRight" data-wow-offset="0" data-wow-duration="1.5s">
    
        <div class="col-md-3 ophtha-box irayfeture-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-cloudPACS/modalities-supported.png" alt="OpthLIVE TELE" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Modalities Supported</h6>
        <p class="content-smallbox">
            CR, DX, CT, MR, US etc (All kind of DICOM Modalities)
        </p>
        
       </div><!--box content-->
    </div><!--col-md-4-->

        <div class="col-md-3 ophtha-box irayfeture-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-cloudPACS/usuability.png" alt="OpthLIVE TELE" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Usability</h6>
        <p class="content-smallbox">
           Very easy to use, intuitive interface, Integration with Tele-radiology SystemImage streaming within LAN to alleviate network congestion.
        </p>
        
       </div><!--box content-->
    </div><!--col-md-4-->

       <div class="col-md-3 ophtha-box irayfeture-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-cloudPACS/dicom-support.png" alt="OpthLIVE TELE" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">DICOM Support</h6>
        <p class="content-smallbox">
             Query, import, send and receive DICOM images. Multi-frame image support.
        </p>
        
       </div><!--box content-->
    </div><!--col-md-4-->

       <div class="col-md-3 ophtha-box irayfeture-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-cloudPACS/imaging-tools.png" alt="OpthLIVE TELE" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Imaging Tools</h6>
        <p class="content-smallbox">
           Multiplanar Reconstruction (MPR), Stacking, Window/Level, VOI LUT support, Zoom/Pan, Magnifying glass, Rotate/Flip.
        </p>
        
       </div><!--box content-->
    </div><!--col-md-4-->

    <div class="col-md-3 ophtha-box irayfeture-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-cloudPACS/measurements.png" alt="OpthLIVE TELE" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">
        <span class="line-1">Measurements &amp;</span>
        <span class="line-2">Annotations</span>
        </h6>
        <p class="content-smallbox">
           Linear, ROIs: Ellipse, Rectangle, polygonal, Mean and standard deviation reporting on ROIs.
        </p>
        
       </div><!--box content-->
    </div><!--col-md-4-->

    

    <div class="col-md-3 ophtha-box irayfeture-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-cloudPACS/overlays.png" alt="OpthLIVE TELE" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Overlays</h6>
        <p class="content-smallbox">
           Study/image information, DICOM overlays, Image scale, Shutters, Individual toggles for all overlays.
        </p>
        
       </div><!--box content-->
    </div><!--col-md-4-->

    <div class="col-md-3 ophtha-box irayfeture-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-cloudPACS/utilities.png" alt="OpthLIVE TELE" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Utilities</h6>
        <p class="content-smallbox">
          Clipboard, Export to JPG, AVI, DICOM header viewer, Study anonymization, Ability to open files from Windows Explorer.
        </p>
        
       </div><!--box content-->
    </div><!--col-md-4-->

    <div class="col-md-3 ophtha-box irayfeture-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-cloudPACS/media-write.png" alt="OpthLIVE TELE" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Media Write</h6>
        <p class="content-smallbox">
           Burn images to CD/DVD/Blu-ray, along with our portable image viewer.
        </p>
        
       </div><!--box content-->
    </div><!--col-md-4-->

    <div class="col-md-3 ophtha-box irayfeture-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-cloudPACS/3D.png" alt="OpthLIVE TELE" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">3D</h6>
        <p class="content-smallbox">
            3D rendering and reconstruction
        </p>
        
       </div><!--box content-->
    </div><!--col-md-4-->

    <div class="col-md-3 ophtha-box irayfeture-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-cloudPACS/dicom-print.png" alt="OpthLIVE TELE" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">DICOM Print</h6>
        <p class="content-smallbox">
          Print images in true-size and color on DICOM conformant printers.
        </p>
        
       </div><!--box content-->
    </div><!--col-md-4-->

    <div class="col-md-3 ophtha-box irayfeture-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-cloudPACS/structured-reporting.png" alt="OpthLIVE TELE" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Structured Reporting</h6>
        <p class="content-smallbox">
          Template driven reporting tool, Ability to create templates for specific users, Digital Signature.
        </p>
        
       </div><!--box content-->
    </div><!--col-md-4-->





  </div><!--content wrapper-->
  </div><!--container--> 
  </div><!--wrapper-->
</div> <!--SECTION4-->

<div class="clearfix"></div>

<!--section 5-->

<div class="section-5" >

<div id="myCarousel1" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel1" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel1" data-slide-to="1"></li>
  
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-cloudPACS/01-slider-dicom-print-screen.png" alt="OpthLIVE CLINICS">
    </div>

    <div class="item">
      <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-cloudPACS/02-slider-dicom-print-screen.png" alt="OpthLIVE CLINICS" >
    
    </div>

</div>


</div><!--section5-->


<div class="clearfix"></div>

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header popform">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Request for Live Demo</h4>
      </div>
      <div class="modal-body">
        <?php echo do_shortcode( '[contact-form-7 id="85" title="Live Demo"]' ); ?>
      </div>
      <div class="modal-footer">

      </div>
    </div>
  </div>
</div>
</div>
<!--modal-->


</div><!--container-fluid-->
<?php get_footer(); ?>
