<?php
/*
 * Template Name:  templateBlog page
 */
$deserve_options = get_option('deserve_theme_options');

get_header();
?>

<div class="container">
  <div class="col-md-4">
  <?php query_posts( array( 'cat' => -0, 'paged'=> $paged ) ); ?>

  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>

  

            <div class="post" id="post-<?php the_ID(); ?>">
        <h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
        <p class="postmetadata">Posted by <?php the_author_posts_link(); ?> on <?php the_time('F jS, Y') ?> &bull; Categorized as <?php the_category(', ') ?> &bull; <?php comments_popup_link('No Comments »', '1 Comment »', '% Comments »'); ?>
        </p>
        <div class="entry">
          <?php the_excerpt(); ?>
        </div>
      </div>

  <?php endwhile; ?>

  <?php else : ?>

    <h1 class="center">Not Found</h1>
    <p class="center">Sorry, but you are looking for something that isn't here.</p>
    <?php include (TEMPLATEPATH . "/searchform.php"); ?>

  <?php endif; wp_reset_query(); ?>
</div> 
<div class="col-md-4">
  <?php if(have_posts()) : ?>
     <?php while(have_posts()) : the_post(); ?>
          <div class="post"> 
               <h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
               <div class="entry">  
                    <?php the_content(); ?>
                    <?php
                    $current_date ="";
                    $count_posts = wp_count_posts();
                    $nextpost = 0;
                    $published_posts = $count_posts->publish;
                    $myposts = get_posts(array('posts_per_page'=>$published_posts)); 
                 foreach($myposts as $post) :
                         $nextpost++;
                         setup_postdata($post);
                         $date = get_the_date("F Y");   
                         if($current_date!=$date): 
                              if($nextpost>1): ?> 
                                   </ol>
                              <?php endif; ?> 
                              <strong><?php echo $date; ?></strong><ol start = "<?php echo $nextpost; ?>">
                              <?php $current_date=$date;
                         endif; ?>
                         <li><?php the_title(); ?> &bull; <a href = "<?php the_permalink(); ?>">link</a></li>
                    <?php endforeach; wp_reset_postdata(); ?>
                    </ol>
              </div>
          </div>
     <?php endwhile; ?>
<?php endif; ?>
</div>
</div>






<?php get_sidebar(); ?> 
</div><!--container-->
<?php get_footer(); ?>
