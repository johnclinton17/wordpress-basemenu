<?php
/*
 * Template Name: OpthaLIVE CLINIC page
 */
$deserve_options = get_option('deserve_theme_options');

get_header();
?>

<div class="container-fluid">
  <a data-toggle="modal" data-target="#myModal">
    <div class="float-demo" >

      <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/live-demo.png" alt="LIVE DEMO" >
      <span class="float-style">Request For Live Demo</span>
     </div> 
  </a>
    <!--section1 ends-->
<div class="section-1 background-height background-heightnew" >

<img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE/Banner.png" alt="LIVE DEMO" >
<div class="carousel-caption static-ban">
        <h3>A Global Partner to Address<br> Your Local Needs</h3>
        <button class="slider-but"><a href="<?php echo esc_url(home_url('')); ?>/contact-us">Contact us for More Info</a></button>
</div>

</div> 



<!--section1 ends-->

<!--section 2-->

<div class="section-2" >
  <div class="container">
    <div class="ophtha-sextion1 opthalive-section">
            <h2 class="section-title">OpthLIVE CLINICS</h2>
            <span class="border-green"></span>  

            <p class="content-box">
            <span class="line-1">OpthLIVE Clinics is the only dedicated practice management system for ophthalmology </span>
            <span class="line-2">clinics, vision care centres & optical shops.</span>
        
      </p>
    </div>

   <div class="OpthLIVE-wrapper1 "> 
    <div class="col-md-3 ophtha-box opthLIve-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE/Registration.png" alt="OpthLIVE TELE" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Registration</h6>
        <p class="content-smallbox">
        <span class="boxline-1"> Capturing basic patient details</span>    
        <span class="boxline-2">such as name, age, gender,</span>    
        <span class="boxline-3">marital status, etc for registration.</span>    
        </p>
       </div><!--box content-->
    </div><!--col-md-3-->

    <div class="col-md-3 ophtha-box opthLIve-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE/payemnt-collection.png" alt="OpthLIVE CLINICS" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Payment Collection</h6>
        <p class="content-smallbox">
        <span class="boxline-1">Collecting payments for procedures</span>    
        <span class="boxline-2">and maintaining a record of</span>    
        <span class="boxline-3">the same.</span>    
        </p>
       </div><!--box content-->
    </div><!--col-md-3-->  

     <div class="col-md-3 ophtha-box opthLIve-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE/bill-payment.png" alt="OpthLIVE HMIS" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Bill Payment</h6>
        <p class="content-smallbox">
        <span class="boxline-1">Collecting payments for procedures</span>    
        <span class="boxline-2">and maintaining a record of</span>    
        <span class="boxline-3">the same.</span>    
        </p>
       </div><!--box content-->
    </div><!--col-md-3--> 

    <div class="col-md-3 ophtha-box opthLIve-box">
           <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE/appoint-scheduling.png" alt="OpthLIVE HMIS" class="img-responsive">
           
           <div class="box-content"> 
            <h6 class="box-title">Appointment  Scheduling</h6>
            <p class="content-smallbox">
            <span class="boxline-1">Scheduling patient appointment with</span>    
            <span class="boxline-2">healthcare professionals.</span>    
              
            </p>
           </div><!--box content-->
        </div><!--col-md-3-->

        <div class="col-md-3 ophtha-box opthLIve-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE/casesheet-management.png" alt="OpthLIVE TELE" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Case Sheet Management</h6>
        <p class="content-smallbox">
        <span class="boxline-1">Add and edit the case sheet details</span>    
        <span class="boxline-2">of patients</span>     
        </p>
       </div><!--box content-->
    </div><!--col-md-3-->

    <div class="col-md-3 ophtha-box opthLIve-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE/reporting.png" alt="OpthLIVE CLINICS" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Reporting</h6>
        <p class="content-smallbox">
        <span class="boxline-1">Diagnose the study and prepare</span>    
        <span class="boxline-2">diagnostic reports.</span>       
        </p>
       </div><!--box content-->
    </div><!--col-md-3-->  

     <div class="col-md-3 ophtha-box opthLIve-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE/patient-categorization.png" alt="OpthLIVE HMIS" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Patient Categorization</h6>
        <p class="content-smallbox">
        <span class="boxline-1">Categorize the patients as blind,</span>    
        <span class="boxline-2">visually impaired or general patients</span>    
        <span class="boxline-3">based on visual acuity values</span>    
        </p>
       </div><!--box content-->
    </div><!--col-md-3--> 

    <div class="col-md-3 ophtha-box opthLIve-box">
           <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE/prescription.png" alt="OpthLIVE HMIS" class="img-responsive">
           
           <div class="box-content"> 
            <h6 class="box-title">Prescriptions for spectacles</h6>
            <p class="content-smallbox">
            <span class="boxline-1">Prescription for spectacles & drugs</span>    
              
            </p>
           </div><!--box content-->
        </div><!--col-md-3-->

        <div class="col-md-3 ophtha-box opthLIve-box">
           <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE/refferal-module.png" alt="OpthLIVE HMIS" class="img-responsive">
           
           <div class="box-content"> 
            <h6 class="box-title">Referral Module</h6>
            <p class="content-smallbox">
            <span class="boxline-1">Refer patients for surgery and many</span>    
            <span class="boxline-2">more customizable features.</span>  
            </p>
           </div><!--box content-->
        </div><!--col-md-3-->

    
  </div><!--wrapper-->

</div><!--container-->

</div>

<!--section 2 ends-->
<!--section3-->
<div class="section-3" >
  <div class="container-fluid benefits-wrapper">
  <div class="container">
    
    <div class="ophtha-sextion1">
        <h2 class="section-title">Benefits</h2>
        <span class="border-green"></span>  
    </div>


    <div class="OPHTHALIVEWRAPPER wow slideInDown" data-wow-offset="0" data-wow-duration="1.5s">
    <div class="col-md-4 ophtha-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLive-Tele.png" alt="OpthLIVE TELE" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Get an Ophthalmologist Opinion</h6>
        <p class="content-smallbox">
           Besides selling glasses and contact lenses, the growth of an optical store depends on efficient operations and presence of in house optometrists. The stores can additonally capture retinal images and take suggesstions from an opthamologist through OpthLIVE Clinics without their physical presence in the store. This can add on to the customer value as most optical stores today do not have a touch point with the doctors and are more inclined towards a fashion retail store.
        </p>
        
       </div><!--box content-->
    </div><!--col-md-4-->

    <div class="col-md-4 ophtha-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLive-Clics.png" alt="OpthLIVE CLINICS" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Improve Operational Efficiency</h6>
        <p class="content-smallbox">
        Clinics can improve their revenue cycle management, monitor and manage patient
        details and improve their operation by also delivering enhanced patient care.  
        </p>
        
       </div><!--box content-->
    </div><!--col-md-4-->  

    <div class="col-md-4 ophtha-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLive-Hmis.png" alt="OpthLIVE HMIS" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Manage your Complete Network</h6>
        <p class="content-smallbox">
        OpthLive Clinics is currently being used by Operation Eyesight Universal in the management
        of their Vision Centres in addition to being used
        for National Ophthalmic screening networks
        and in tertiary hospitals.    
        </p>
       </div><!--box content-->
    </div><!--col-md-4-->  
  </div><!--content wrapper-->
  </div><!--container--> 
  </div><!--wrapper-->
</div> <!--SECTION3-->

<div class="clearfix"></div>

<!--section 4-->

<div class="section-4" >

    <div id="myCarousel" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE/Slider-Registration.png" alt="OpthLIVE" >
    </div>

    <div class="item">
      <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE/Slider-Prescription.png" alt="OpthLIVE" >
    </div>

  </div>

</div>

</div><!--section5-->
<!--section 4 ends-->
<div class="clearfix"></div>


<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header popform">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Request for Live Demo</h4>
      </div>
      <div class="modal-body">
        <?php echo do_shortcode( '[contact-form-7 id="85" title="Live Demo"]' ); ?>
      </div>
      <div class="modal-footer">

      </div>
    </div>
  </div>
</div>
</div>
<!--modal-->


</div><!--container-fluid-->
<?php get_footer(); ?>
