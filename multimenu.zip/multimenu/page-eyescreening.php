<?php
/*
 * Template Name: Eyescreening page
 */
$deserve_options = get_option('deserve_theme_options');

get_header();
?>

<div class="container-fluid">
  <a data-toggle="modal" data-target="#myModal">
    <div class="float-demo" >

      <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/live-demo.png" alt="LIVE DEMO" >
      <span class="float-style">Request For Live Demo</span>
     </div> 
  </a>
    <!--section1 ends-->
<div class="section-1 background-height " >

 <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Banner-2.png" alt="OpthLIVE HMIS" class="img-responsive">
<div class="carousel-caption static-ban">
        <h3>Integrating Ophthalmic care throughout the value chain</h3>
       <button class="slider-but"><a href="<?php echo esc_url(home_url('')); ?>/contact-us">Contact us for More Info</a></button>
      </div>
</div>
<!--section1 ends-->
<!--section2-->
<div class="section-2 page-bottom" >


    <div class="ophtha-sextion1">
            <h2 class="section-title">Eye Screening Services</h2>
            <span class="border-green"></span>  
    </div>

   <div class="container"> 
    <div class="center-image">
     <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Eyescreening-services/eye-screening-services.png" alt="Eyescreening-services" >
    </div> 
    <p class="content-box">
            <span class="line-1">Eye care Hospital / organization having vision centres in Tier 2  cities and community screening sites in Tier 3 cities or A  diabetic / nephrology / endocrine clinic or a</span>
            <span class="line-2"> pharma company wanting to offer eye screening services to check the impact of these diseases on eyes,Pellucid offers community eye screening</span>
            <span class="line-3"> programs for NGOs and MoHs by partnering with eye hospitals &amp; clinics.The screening is usually done by tying up with top fundus camera </span>
            <span class="line-1">manufacturers who can provide the equipment at reasonable rates.Pellucid is also experimenting to carry this out using mobile devices</span>
            <span class="line-2"> with an attachment which are affordable and easy to carry.Retinal images captured at the community centres can be transferred</span>
            <span class="line-3">  through cloud to the vision centres where an ophthalmologist can diagnose and report the possible anomalies.</span> 
            </p>
   </div><!--container-->
    
   
</div> <!--SECTION2-->

<div class="clearfix"></div>

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header popform">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Request for Live Demo</h4>
      </div>
      <div class="modal-body">
        <?php echo do_shortcode( '[contact-form-7 id="85" title="Live Demo"]' ); ?>
      </div>
      <div class="modal-footer">

      </div>
    </div>
  </div>
</div>
</div>
<!--modal-->



</div><!--container-fluid-->
<?php get_footer(); ?>
