<?php
/*
 * Template Name: About us page
 */
$deserve_options = get_option('deserve_theme_options');

get_header();
?>

<div class="container-fluid">
  <a data-toggle="modal" data-target="#myModal">
    <div class="float-demo" >

      <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/live-demo.png" alt="LIVE DEMO" >
      <span class="float-style">Request For Live Demo</span>
     </div> 
  </a>
    

    <!--section1 ends-->
<div class="section-1 background-height " >

    <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/banner-4.png" alt="OpthLIVE HMIS" class="img-responsive">
    <div class="carousel-caption static-ban">
        <h3>Eye Care on Cloud Nine</h3>
       <button class="slider-but"><a href="<?php echo esc_url(home_url('')); ?>/contact-us">Contact us for More Info</a></button>
    </div>
</div>



<!--section1 ends-->
<div class="clearfix"></div>
<!--section 2-->

<div class="section-2">
  <div class="container  ">
    <div class="ophtha-sextion1 opthalive-section">
            <h2 class="section-title">Why Pellucid ?</h2>
            <span class="border-green"></span>  

            <p class="content-box">
            <span class="line-1">Pellucid is a company at the intersection of medical imaging, clinical information and cloud </span>
            <span class="line-2">computing and is a leader in preventive screening treatment.</span>   
      </p>
    </div>

   <div class="OpthLIVE-wrapper1 about-wrapper wow slideInLeft" data-wow-offset="0" data-wow-duration="1.5s"> 
    <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/About-Us/Why-pellucid.png" alt="why pellucid" >

  </div><!--wrapper-->

</div><!--container-->

</div>

<!--section 2 ends-->

<!--section3-->
<div class="section-3" >
<div class="container-fluid benefits-wrapper">

    <div class="ophtha-sextion1">
            <h2 class="section-title">Core Belief</h2>
            <span class="border-green"></span> 

            <p class="content-box">
            <span class="line-1">Our innovation is driven based on the belief that medical imaging is the central piece for accurate diagnosis. As a result, we</span>
            <span class="line-2">strive to offer complete solutions to practices that use medical imaging for ophthalmology</span>   
      </p>
      <div class="about-video">

        <iframe width="1350" height="650" src="https://www.youtube.com/embed/r0FeMsIBooA" frameborder="0" allowfullscreen></iframe>
      </div>  

    </div>

   
    
</div>   
</div> <!--SECTION3-->


<!--section4-->
<div class="section-4" >


    <div class="ophtha-sextion1">
            <h2 class="section-title">Timeline</h2>
            <span class="border-green"></span> 

    </div>
    <div class="container-fluid">
      <section class="timeline wow slideInRight">
          <article class="timeline__item">
              <h1>
                  <h1 class="timeline__itemTitle"><span class="left-text">Jan 2010</span>Radiology product launched, secured Medall</h1>
              </h1>
              
          </article>
          <article class="timeline__item">
              <h1>
                  <h1 class="timeline__itemTitle">TechSpark award by Microsoft &amp; CNBC<span class="right-text">Aug 2010</span></h1>
              </h1>
              
          </article>
          <article class="timeline__item">
              <h1>
                  <h1 class="timeline__itemTitle"><span class="left-text">Nov 2012</span>Indonesia Government deal</h1>
              </h1>
              
          </article>
          <article class="timeline__item">
              <h1>
                  <h1 class="timeline__itemTitle">Tele-ophthalmology for  Aravind Eye Hospital<span class="right-text">Jan 2013</span></h1>
              </h1>
              
          </article>
          <article class="timeline__item">
              
              <h1>
                  <h1 class="timeline__itemTitle"><span class="left-text">May 2013</span>Ophthalmology product launch, engagement with Topcon</h1>
              </h1>
              
          </article>
          <article class="timeline__item">
              <h1>
                  <h1 class="timeline__itemTitle">Ophthalmology Pilot with Vietnam MoH<span class="right-text">Jan 2014</span></h1>
              </h1>
          </article>
          <article class="timeline__item">
              <h1>
                  <h1 class="timeline__itemTitle"><span class="left-text">June 2014</span>Singapore National deal</h1>
              </h1>

          </article>
          <article class="timeline__item">
              <h1>
                  <h1 class="timeline__itemTitle">2015</h1>
              </h1>
              <p class="timeline__itemDescription"></p>
          </article>
      </section>


   </div>
    
   
</div><!--SECTION-->

<!--section5-->

<div class="section-5 ">
  <div class="container-fluid benefits-wrapper ">
  <div class="container">
    
    <div class="ophtha-sextion1">
        <h2 class="section-title">Leadership Team</h2>
        <span class="border-green"></span>  
    </div>


<div class="OPHTHALIVEWRAPPER about wow slideInDown" data-wow-offset="0" data-wow-duration="1.5s">
    
  <div class="aboutteam-wrapper">
    <div class="col-md-4  aboutteam-image">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/About-Us/Untitled-12.jpg" alt="OpthLIVE TELE" class="img-responsive">
    </div>

      <div class="col-md-8 aboutteam-content"> 
       <div class="box-content"> 
        <h6 class="box-title green-hover">Rajesh Sukumaran</h6>
        <span class="job-post">Founder and CEO</span>
        <p class="content-smallbox">
           Rajesh founded Pellucid and has 12 years of leadership experience having been a driver of commercialization in listed Healthcare companies and start-ups alike. He is an expert level consultant in medical imaging technologies and holds a Computer Sciences Engineering Degree from the University of Madras.
        </p>
        
       </div><!--box content-->
    </div><!--col-md-8-->
  </div><!--aboutteam-wrapper-->  

<div class="aboutteam-wrapper">
  <div class="col-md-4  aboutteam-image">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/About-Us/Untitled-12.jpg" alt="OpthLIVE TELE" class="img-responsive">
    </div>

      <div class="col-md-8 aboutteam-content"> 
       <div class="box-content"> 
        <h6 class="box-title green-hover">Alagaraja Ravindra Raja</h6>
        <span class="job-post">CTO</span>
        <p class="content-smallbox">
           Alagu drives Pellucid's Product Development efforts focused on developing solutions for Healthcare and Clinical IT domains. He has 11 years of experience, specializing in Telemedicine and Image Management and is an expert on Windows™, Cloud and DICOM technologies.
        </p>
        
       </div><!--box content-->
    </div><!--col-md-8-->
    </div><!--aboutteam-wrapper-->    


  </div><!--content wrapper-->
  </div><!--container--> 
  </div><!--wrapper-->
</div> <!--SECTION4-->
<div class="clearfix"></div>

<div class="clearfix"></div>
<div class="section-6" >
<div class="container-fluid ">

    <div class="ophtha-sextion1">
            <h2 class="section-title">BOD &amp; Investors</h2>
            <span class="border-green"></span> 
    </div>

   <div class="team-wrapper"> 
    <div class="col-md-4 ophtha-box">
      <a data-toggle="modal" data-target="#myModal1 ">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/About-Us/Untitled-12.jpg" alt="Ophthalmology" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title pad0">Ravi Govindan</h6>
        <p class="content-smallbox">
        <span class="boxline-1">Chairman of the Board</span>        
        </p>
        
       </div><!--box content-->
     </a>
    </div><!--col-md-4-->
   

    <div class="col-md-4 ophtha-box">
      <a data-toggle="modal" data-target="#myModal2">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/About-Us/Untitled-12.jpg" alt="Ophthalmology" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title pad0">GL Sim</h6>
        <p class="content-smallbox">
        <span class="boxline-1">Executive Director</span>    
          
        </p>
        
       </div><!--box content-->
      </a> 
    </div><!--col-md-4-->

    <div class="col-md-4 ophtha-box">
      <a data-toggle="modal" data-target="#myModal3">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/About-Us/Untitled-12.jpg" alt="Ophthalmology" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title pad0">Ted Ong kok Wah</h6>
        <p class="content-smallbox">
        <span class="boxline-1">Executive Director</span>        
        </p>
        
       </div><!--box content-->
      </a> 
    </div><!--col-md-4-->

    <div class="col-md-4 ophtha-box">
      <a data-toggle="modal" data-target="#myModal4">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/About-Us/Untitled-12.jpg" alt="Ophthalmology" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title pad0">Rajesh Sukumaran</h6>
        <p class="content-smallbox">
        <span class="boxline-1">Chairman of the Board</span>       
        </p>
        
       </div><!--box content-->
      </a> 
    </div><!--col-md-4-->

    <div class="col-md-4 ophtha-box">
      <a data-toggle="modal" data-target="#myModal5">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/About-Us/Untitled-12.jpg" alt="Ophthalmology" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title pad0">Dr. Bernanrd Lee</h6>
        <p class="content-smallbox">
        <span class="boxline-1">Executive Director</span>      
        </p>
        
       </div><!--box content-->
     </a>
    </div><!--col-md-4-->

    <div class="col-md-4 ophtha-box">
      <a data-toggle="modal" data-target="#myModal6">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/About-Us/Untitled-12.jpg" alt="Ophthalmology" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title pad0">Mercatus Venture Capital Pte Ltd</h6>
        <p class="content-smallbox">
        <span class="boxline-1">Company</span>        
        </p>
        
       </div><!--box content-->
     </a>
    </div><!--col-md-4-->   
  </div><!--team wrapper-->  
</div>   
</div> <!--SECTION6-->

<!--modal one-->
<div class="modal fade bs-example-modal-lg" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
       
      </div>
      <div class="modal-body">
        <div class="col-md-4  aboutteam-image">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/About-Us/Untitled-12.jpg" alt="OpthLIVE TELE" class="img-responsive">
    </div>

      <div class="col-md-8 aboutteam-content"> 
       <div class="box-content"> 
        <h6 class="box-title">RAVI GOVINDAN</h6>
        <span class="job-post">Chairman of the Board</span>
        <p class="content-smallbox">
          A serial entrepreneur with business spread across AsiaPacific. Ravi was formerly the Group President of Fisher Scientific in the Asia Pacific Region; he continues to provide strategic advice on Asia Pacific Region for Latona Associates Inc, a private investment and financial advisory firm based in New York.
        </p>
        
       </div><!--box content-->
    </div><!--col-md-8-->
      </div>
      <div class="modal-footer">

      </div>
    </div>
  </div>
</div>
</div>
<!--modal one ends here-->
<!--modal two-->
<div class="modal fade  bs-example-modal-lg" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        
      </div>
      <div class="modal-body">
        <div class="col-md-4  aboutteam-image">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/About-Us/Untitled-12.jpg" alt="OpthLIVE TELE" class="img-responsive">
    </div>

      <div class="col-md-8 aboutteam-content"> 
       <div class="box-content"> 
        <h6 class="box-title">GL Sim</h6>
        <span class="job-post">Executive Director</span>
        <p class="content-smallbox">
          GL Sim is the group Chairman of Zicom Group Ltd, He is also a directorof SPRING Singapore. He is a member of the SNEC/SERI Incubation Board as well as a member of the Strategic Advisory Panel for the Diagnostic Development Hub directly funded by the Prime Minister Office.
        </p>
        
       </div><!--box content-->
    </div><!--col-md-8-->
      </div>
      <div class="modal-footer">

      </div>
    </div>
  </div>
</div>
</div>
<!--modal two ends here-->
<!--modal three-->
<div class="modal fade  bs-example-modal-lg" id="myModal3" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        
      </div>
      <div class="modal-body">
        <div class="col-md-4  aboutteam-image">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/About-Us/Untitled-12.jpg" alt="OpthLIVE TELE" class="img-responsive">
    </div>

      <div class="col-md-8 aboutteam-content"> 
       <div class="box-content"> 
        <h6 class="box-title">Ted Ong kok Wah</h6>
        <span class="job-post">Executive Director</span>
        <p class="content-smallbox">
           Ted was previously the CEO/Exe. Director of Chuan Hupgroup, He serves as the Director of "The Shipowner's Mutual Protection And Indemnity Association" (Luxembourg) and The Shipowner's Insurance Singapore Pte Ltd.
        </p>
        
       </div><!--box content-->
    </div><!--col-md-8-->
      </div>
      <div class="modal-footer">

      </div>
    </div>
  </div>
</div>
</div>
<!--modal three ends here-->

<!--modal four-->
<div class="modal fade  bs-example-modal-lg" id="myModal4" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        
      </div>
      <div class="modal-body">
        <div class="col-md-4  aboutteam-image">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/About-Us/Untitled-12.jpg" alt="OpthLIVE TELE" class="img-responsive">
    </div>

      <div class="col-md-8 aboutteam-content"> 
       <div class="box-content"> 
        <h6 class="box-title">Rajesh Sukumaran</h6>
        <span class="job-post">Executive Director</span>
        <p class="content-smallbox">
           Rajesh founded Pellucid in 2008, and leads the company as its CEO
        </p>
        
       </div><!--box content-->
    </div><!--col-md-8-->
      </div>
      <div class="modal-footer">

      </div>
    </div>
  </div>
</div>
</div>
<!--modal four ends here-->
<!--modal five-->
<div class="modal fade  bs-example-modal-lg" id="myModal5" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
       
      </div>
      <div class="modal-body">
        <div class="col-md-4  aboutteam-image">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/About-Us/Untitled-12.jpg" alt="OpthLIVE TELE" class="img-responsive">
    </div>

      <div class="col-md-8 aboutteam-content"> 
       <div class="box-content"> 
        <h6 class="box-title">Dr. Bernanrd Lee</h6>
        <span class="job-post">Executive Director</span>
        <p class="content-smallbox">
           Dr Lee is a renowned pain specialist in Singapore, he is the founder of Singapore Pain Care Center as well as the director and consultant of the Women's Pain Center in KK Women's and Children's hospital.
        </p>
        
       </div><!--box content-->
    </div><!--col-md-8-->
      </div>
      <div class="modal-footer">

      </div>
    </div>
  </div>
</div>
</div>
<!--modal five ends here-->
<!--modal six-->
<div class="modal fade  bs-example-modal-lg" id="myModal6" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      
      </div>
      <div class="modal-body">
        <div class="col-md-4  aboutteam-image">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/About-Us/Untitled-12.jpg" alt="OpthLIVE TELE" class="img-responsive">
    </div>

      <div class="col-md-8 aboutteam-content"> 
       <div class="box-content"> 
        <h6 class="box-title">Mercatus Venture Capital Pte Ltd</h6>
        
        <p class="content-smallbox">
           Mercatus Group helps businesses across a diverse area of services including Venture and Angel Funding, Securing Grants, Public and Private Equity, Mergers and Acquisitions, Corporate Restructurings, Financial Advisory, Initial Public Offerings and Strategic Partnerships. Our continuous efforts and track record in helping ideas grow has been acknowledged by SPRING Singapore with the awarding of the status of 'Venture Incubators'.
        </p>
        
       </div><!--box content-->
    </div><!--col-md-8-->
      </div>
      <div class="modal-footer">

      </div>
    </div>
  </div>
</div>
</div>
<!--modal six ends here-->

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header popform">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Request for Live Demo</h4>
      </div>
      <div class="modal-body">
        <?php echo do_shortcode( '[contact-form-7 id="85" title="Live Demo"]' ); ?>
      </div>
      <div class="modal-footer">

      </div>
    </div>
  </div>
</div>
</div>
<!--modal-->

</div><!--container-fluid-->
<?php get_footer(); ?>
