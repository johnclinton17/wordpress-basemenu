<?php
/*
 * Template Name: OpthaLIVE HMIS page
 */
$deserve_options = get_option('deserve_theme_options');

get_header();
?>

<div class="container-fluid">
  <a data-toggle="modal" data-target="#myModal">
    <div class="float-demo" >

      <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/live-demo.png" alt="LIVE DEMO" >
      <span class="float-style">Request For Live Demo</span>
     </div> 
  </a>
    <!--section1 ends-->
<div class="section-1 background-height background-heightnew" >

 <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-HMIS/banner.png" alt="OpthLIVE HMIS" class="img-responsive">
<div class="carousel-caption static-ban">
        <h3>Eye Care on Cloud Nine</h3>
       <button class="slider-but"><a href="<?php echo esc_url(home_url('')); ?>/contact-us">Contact us for More Info</a></button>
      </div>
</div>

<!--section1 ends-->

<!--section 2-->

<div class="section-2" >
  <div class="container">
    <div class="ophtha-sextion1 opthalive-section">
            <h2 class="section-title">OpthLIVE HMIS</h2>
            <span class="border-green"></span>  

            <p class="content-box">
            <span class="line-1">OpthLIVE HMIS is the only dedicated system for ophthalmology speciality hospital, it combines Hospital information system </span>
            <span class="line-2">with a ophthalmology equipment interface system and PACS</span>
        
      </p>
    </div>

   <div class="OpthLIVE-wrapper1 "> 
    <div class="col-md-3 ophtha-box opthLIve-box">
      <div class="opthlive-imagewrapper">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-HMIS/patient-registration.png" alt="OpthLIVE TELE" class="img-responsive">
      </div> 
       <div class="box-content"> 
        <h6 class="box-title">Patient registration</h6>
        <p class="content-smallbox">
        <span class="boxline-1"> Capturing basic patient details </span>    
        <span class="boxline-2"> as name, age, gender,marital status,</span>    
        <span class="boxline-3"> etc for registration.</span>    
        </p>
       </div><!--box content-->
    </div><!--col-md-3-->

    <div class="col-md-3 ophtha-box opthLIve-box">
      <div class="opthlive-imagewrapper">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-HMIS/appointment-scheduler.png" alt="OpthLIVE CLINICS" class="img-responsive">
      </div> 
       <div class="box-content"> 
        <h6 class="box-title">Appointment Scheduler</h6>
        <p class="content-smallbox">
        <span class="boxline-1">Scheduling patient appointment</span>    
        <span class="boxline-2">with doctors and other paramedical</span>    
        <span class="boxline-3">staff.</span>    
        </p>
       </div><!--box content-->
    </div><!--col-md-3-->  

     <div class="col-md-3 ophtha-box opthLIve-box">
      <div class="opthlive-imagewrapper">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-HMIS/billing.png" alt="OpthLIVE HMIS" class="img-responsive">
      </div> 
       <div class="box-content"> 
        <h6 class="box-title">Billing</h6>
        <p class="content-smallbox">
        <span class="boxline-1">Department wise bill processing</span>    
        <span class="boxline-2">module.</span>    
       
        </p>
       </div><!--box content-->
    </div><!--col-md-3--> 

    <div class="col-md-3 ophtha-box opthLIve-box">
      <div class="opthlive-imagewrapper">
           <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-HMIS/patient-history.png" alt="OpthLIVE HMIS" class="img-responsive">
      </div>     
           <div class="box-content"> 
            <h6 class="box-title">Patient History</h6>
            <p class="content-smallbox">
            <span class="boxline-1">Upload of case sheet, archieving and</span>    
            <span class="boxline-2">retrieval of patient history.</span>    
              
            </p>
           </div><!--box content-->
        </div><!--col-md-3-->

        <div class="col-md-3 ophtha-box opthLIve-box">
      <div class="opthlive-imagewrapper">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-HMIS/interface-with-modalities.png" alt="OpthLIVE TELE" class="img-responsive">
      </div>
       <div class="box-content"> 
        <h6 class="box-title">Interface with Modalities</h6>
        <p class="content-smallbox">
        <span class="boxline-1">Complete integration with modalities</span>    
        <span class="boxline-2">such as  OCT / Fundus Images /</span>     
        <span class="boxline-3">Visual Field / Slit Lamp.</span>     
        </p>
       </div><!--box content-->
    </div><!--col-md-3-->

    <div class="col-md-3 ophtha-box opthLIve-box">
      <div class="opthlive-imagewrapper">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-HMIS/patient-alerts.png" alt="OpthLIVE CLINICS" class="img-responsive">
      </div> 
       <div class="box-content"> 
        <h6 class="box-title">Patient Alerts</h6>
        <p class="content-smallbox">
        <span class="boxline-1">Capturing and uploading  of</span>    
        <span class="boxline-2">consultation patient’s history details.</span>       
        </p>
       </div><!--box content-->
    </div><!--col-md-3-->  

     <div class="col-md-3 ophtha-box opthLIve-box">
      <div class="opthlive-imagewrapper">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-HMIS/drug-prescription.png" alt="OpthLIVE HMIS" class="img-responsive">
      </div> 
       <div class="box-content"> 
        <h6 class="box-title">Drug Prescription</h6>
        <p class="content-smallbox">
        <span class="boxline-1">Detailed module for drugs that are</span>    
        <span class="boxline-2">being prescribed which is linked</span>    
        <span class="boxline-3">to inventory.</span>  
        </p>
       </div><!--box content-->
    </div><!--col-md-3--> 

    <div class="col-md-3 ophtha-box opthLIve-box">
      <div class="opthlive-imagewrapper">
           <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-HMIS/glass-prescription.png" alt="OpthLIVE HMIS" class="img-responsive">
      </div>     
           <div class="box-content"> 
            <h6 class="box-title">Glass Prescription</h6>
            <p class="content-smallbox">
            <span class="boxline-1">Short sight, long sight and cylindrical</span>    
            <span class="boxline-1">power glass prescription.</span>    
              
            </p>
           </div><!--box content-->
        </div><!--col-md-3-->

        <div class="col-md-3 ophtha-box opthLIve-box">
          <div class="opthlive-imagewrapper">
           <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-HMIS/payment-master.png" alt="OpthLIVE HMIS" class="img-responsive">
          </div> 
           <div class="box-content"> 
            <h6 class="box-title">Payment Masters</h6>
            <p class="content-smallbox">
            <span class="boxline-1">A master checklist to display the</span>    
            <span class="boxline-2">payments that are made.</span>  
            </p>
           </div><!--box content-->
        </div><!--col-md-3-->

        <div class="col-md-3 ophtha-box opthLIve-box">
          <div class="opthlive-imagewrapper">
           <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-HMIS/patient-due-collections.png" alt="OpthLIVE HMIS" class="img-responsive">
          </div> 
           <div class="box-content"> 
            <h6 class="box-title">Patient due Collections</h6>
            <p class="content-smallbox">
            <span class="boxline-1">Module to display pending payments</span>    
            <span class="boxline-2">and due date for collection.</span>  
            </p>
           </div><!--box content-->
        </div><!--col-md-3-->

        <div class="col-md-3 ophtha-box opthLIve-box">
          <div class="opthlive-imagewrapper">
           <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-HMIS/discount-master.png" alt="OpthLIVE HMIS" class="img-responsive">
          </div> 
           <div class="box-content"> 
            <h6 class="box-title">Discount Master</h6>
            <p class="content-smallbox">
            <span class="boxline-1">Discount packages and the</span>    
            <span class="boxline-2">corresponding disease list.</span>  
            </p>
           </div><!--box content-->
        </div><!--col-md-3-->

        <div class="col-md-3 ophtha-box opthLIve-box">
          <div class="opthlive-imagewrapper">
           <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-HMIS/billing-patient-type.png" alt="OpthLIVE HMIS" class="img-responsive">
          </div> 
           <div class="box-content"> 
            <h6 class="box-title">Billing based on patient type</h6>
            <p class="content-smallbox">
            <span class="boxline-1">Repeating patients, first time patients</span>    
            <span class="boxline-2">are classified accordingly and billed.</span>  
            </p>
           </div><!--box content-->
        </div><!--col-md-3-->

        <div class="col-md-3 ophtha-box opthLIve-box">
          <div class="opthlive-imagewrapper">
           <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-HMIS/tax-master.png" alt="OpthLIVE HMIS" class="img-responsive">
          </div> 
           <div class="box-content"> 
            <h6 class="box-title">Tax Master</h6>
            <p class="content-smallbox">
            <span class="boxline-1">Tax calculation based on the total</span>    
            <span class="boxline-2">billing and the appropriate</span>  
            <span class="boxline-3">screening.</span>  
            </p>
           </div><!--box content-->
        </div><!--col-md-3-->

        <div class="col-md-3 ophtha-box opthLIve-box">
          <div class="opthlive-imagewrapper">
           <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-HMIS/dashboard-for-all-users.png" alt="OpthLIVE HMIS" class="img-responsive">
          </div> 
           <div class="box-content"> 
            <h6 class="box-title">Dashboard for all the users</h6>
            <p class="content-smallbox">
            <span class="boxline-1">KPIs | BI dashboards | Web based</span>    
            <span class="boxline-2">mobile and tablet views.</span>  
            </p>
           </div><!--box content-->
        </div><!--col-md-3-->

    
  </div><!--wrapper-->

</div><!--container-->

</div>

<!--section 2 ends-->
<!--section3-->
<div class="section-3" >
  <div class="container-fluid benefits-wrapper">
  <div class="container">
    
    <div class="ophtha-sextion1">
        <h2 class="section-title">Benefits</h2>
        <span class="border-green"></span>  
    </div>


    <div class="OPHTHALIVEWRAPPER wow slideInDown" data-wow-offset="0" data-wow-duration="1.5s">
    <div class="col-md-3 ophtha-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-HMIS/stay-connected.png" alt="OpthLIVE TELE" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Stay Connected</h6>
        <p class="content-smallbox">
           Whether you are travelling or present in the hospital premises, seamlessly integrate your billing, stores, OP/ IP, Insurance, Doctor appointments, Operation theatre management and track MIS reports on the go through mobile, tablet or laptop.
        </p>
        
       </div><!--box content-->
    </div><!--col-md-4-->

    <div class="col-md-3 ophtha-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-HMIS/manage-appointments.png" alt="OpthLIVE CLINICS" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Manage Appointments</h6>
        <p class="content-smallbox">
        Our appointment module enables you to book, cancel, reschedule an appointment based on  doctor’s availability and patient requirement. Centralized booking and tracking is possible.  
        </p>
        
       </div><!--box content-->
    </div><!--col-md-4-->  

    <div class="col-md-3 ophtha-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-HMIS/flexible-payment.png" alt="OpthLIVE HMIS" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Flexible Payment Options</h6>
        <p class="content-smallbox">
        OpthLive Clinics is currently being used by Operation Eyesight Universal in the management
        of their Vision Centres in addition to being used for National Ophthalmic screening networks
        and in tertiary hospitals.    
        </p>
       </div><!--box content-->
    </div><!--col-md-4-->  

    <div class="col-md-3 ophtha-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-HMIS/scalable.png" alt="OpthLIVE HMIS" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Scalable</h6>
        <p class="content-smallbox">
        Start now and as your hospital grows and have increased patient foot fall, the software can be scaled. 
        </p>
       </div><!--box content-->
    </div><!--col-md-4-->  


  </div><!--content wrapper-->
  </div><!--container--> 
  </div><!--wrapper-->
</div> <!--SECTION3-->

<div class="clearfix"></div>

<!--section 4-->

<div class="section-4" >
   <div id="myCarousel" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-HMIS/Worklist-dashboard.png" alt="OpthLIVE-HMIS" alt="Chania">
    </div>

    <div class="item">
      
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-HMIS/Worklist-report-report.png" alt="OpthLIVE-HMIS" alt="Chania">
    </div>

    <div class="item">
     <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/OpthLIVE-HMIS/Worklist-drug-prescription.png" alt="OpthLIVE-HMIS" alt="Chania">
    </div>

</div>

</div> 

</div><!--section5-->
<!--section 4 ends-->
<div class="clearfix"></div>



<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header popform">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Request for Live Demo</h4>
      </div>
      <div class="modal-body">
        <?php echo do_shortcode( '[contact-form-7 id="85" title="Live Demo"]' ); ?>
      </div>
      <div class="modal-footer">

      </div>
    </div>
  </div>
</div>
</div>
<!--modal-->

</div><!--container-fluid-->
<?php get_footer(); ?>
