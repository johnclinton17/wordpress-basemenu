<?php
/*
 * Template Name: trusted reeds page
 */
$deserve_options = get_option('deserve_theme_options');

get_header();
?>

<div class="container-fluid">
  <a data-toggle="modal" data-target="#myModal">
    <div class="float-demo" >

      <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/live-demo.png" alt="LIVE DEMO" >
      <span class="float-style">Request For Live Demo</span>
     </div> 
  </a>
    <!--section1 ends-->
<div class="section-1 background-height " >
 <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/trusted-reads-banner.jpg" alt="OpthLIVE HMIS" class="img-responsive">
<div class="carousel-caption static-ban">
        <h3></h3>
       <button class="slider-but"><a href="<?php echo esc_url(home_url('')); ?>/contact-us">Contact us for More Info</a></button>
      </div> 
</div>
<!--section1 ends-->


<!--section3-->
<div class="section-3" >
  <div class="container-fluid benefits-wrapper">
  <div class="container">
    
    <div class="ophtha-sextion1">
        <h2 class="section-title">Trusted Reads</h2>
        <span class="border-green"></span>  
      
        <p class="content-box">
            <span class="line-1">Ensure that your patients get an eye check up report every time they </span>
            <span class="line-2">come for adiabetic / nephrology / endocrine problems.</span>
            </p>
    </div>

</div><!--container-->
   <div class="container">
    <div class="image-align center-image">
     <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Eyescreening-services/Infograph-did-you-know.jpg" alt="Eyescreening-services" >
    </div> 
  </div>
  
  </div><!--wrapper-->
</div> <!--SECTION3-->

<!--section3 ends here-->
<!--section 4-->

<div class="section-4" >

  <div class="container">
    
    <div class="ophtha-sextion1">
        <h2 class="section-title">Trusted Reads</h2>
        <span class="border-green"></span>  
      
        <p class="content-box">
            <span class="line-1">Ensure that your patients get an eye check up report every time they </span>
            <span class="line-2">come for adiabetic / nephrology / endocrine problems.</span>
            </p>
    </div>

</div><!--container-->

  <div class="container">
  <div class="center-image">
     <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Eyescreening-services/Infograph-causes-of-blindness.jpg" alt="Eyescreening-services" >
    </div> 
  </div>
</div>

<!--section 4 ends-->
<div class="section4">
<div class="ophtha-sextion1">
        <h2 class="section-title">Trusted Reads-Reporting as a Service</h2>
        <span class="border-green"></span>  
      
        <p class="content-box">
            <span class="line-1">Pellucid reaches out to the diabetic population to prevent blindness due to Diabetic Retinopathy by working closely with ophthalmologists, diabetic &amp; nephrology</span>
            <span class="line-2">clinicsalong with high end fundus camera manufacturers in delivering quality reports at very minimal turnaround time and cost.</span>
            <span class="line-3">The screening devise, platform and backend ophthalmologists are taken care of by Pellucid where the patients</span>
            <span class="line-1">will get a eye screening report at just $3 ( Rs. 150 ) when they do a diabetic check.</span>
        </p>

                <h2 class="section-title">Benefit to the centres</h2>
        <span class="border-green"></span>  
      
        <ul class="content-box">
            <li class="lineul">Doesn’t require huge investment.</li>
            <li class="lineul">Better value add to the screening packages.</li>
            <li class="lineul">Better patient satisfaction level as they get most services in one place</li>
            <li class="lineul">Any staff with basic knowledge can be trained to take the images</li>
            <li class="lineul">Images are uploaded via internet into our cloud based server and the back end team <br>of Ophthalmologists will send the reports within half an hour.</li>
            <li class="lineul">Patients diagnosed of retinopathy can be referred to a local ophthalmologist</li>
        </ul>
</div>

<div class="ophtha-sextion1">

</div>


</div>

<div class="clearfix"></div>

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header popform">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Request for Live Demo</h4>
      </div>
      <div class="modal-body">
        <?php echo do_shortcode( '[contact-form-7 id="85" title="Live Demo"]' ); ?>
      </div>
      <div class="modal-footer">

      </div>
    </div>
  </div>
</div>
</div>
<!--modal-->



</div><!--container-fluid-->
<?php get_footer(); ?>
