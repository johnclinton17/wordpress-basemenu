<?php
/*
 * Template Name: radiology page
 */
$deserve_options = get_option('deserve_theme_options');

get_header();
?>

<div class="container-fluid">
  <a data-toggle="modal" data-target="#myModal">
    <div class="float-demo" >

      <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/live-demo.png" alt="LIVE DEMO" >
      <span class="float-style">Request For Live Demo</span>
     </div> 
  </a> 
    <!--section1 ends-->
<div class="section-1 background-height background-heightnew" >
      <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Banner.png" alt="LIVE DEMO" >
      <div class="carousel-caption static-ban">
              <h3>Enhance Your Image By Minmising Errors &amp; Turn Around Time</h3>   
              <button class="slider-but"><a href="<?php echo esc_url(home_url('')); ?>/contact-us">Contact us for More Info</a></button>          
      </div>
</div> 

<!--section1 ends-->
<!--section2-->
<div class="section-2" >

   <div class="container-fluid "> 
    <div class=" image-center">
     <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Ophthalmologist/radiology-Infograph.jpg" alt="OpthLIVE HMIS" class="img-responsive">
    </div> 
   </div><!--container-->
    
   
</div> <!--SECTION2-->

<!--section 3-->
<div class="section-3" >
    <div class="ophthalwrapper1-background">
      <div class=" container ophthalwrapper-box">  
        <div class="ophthalmology-section1">
            <h2 class="section-title">RadLIVE  Platform</h2>
            <span class="border-green"></span>

            <p class="content-box">
            <span class="line-1">RadLIVE is a comprehensive system for radiology clinics and hospitals that serves all modalities and healthcare environments.</span>
            <span class="line-2">It is the next generation diagnostic imaging platform on the cloud.</span>
            </p>
        </div>

        <div class="col-md-3 box-statics">
            <div class="opthlive-features">
              <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Ophthalmologist/scalable.png" alt="OpthLIVE HMIS" class="img-responsive">
            </div>  
             <span class="stat-text line-1">Scalable</span>
             
        </div>
        <div class="col-md-3 box-statics">
             <div class="opthlive-features">
              <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Ophthalmologist/web-based.png" alt="OpthLIVE HMIS" class="img-responsive">
            </div> 
             <span class="stat-text line-1">Web-Based</span>
             
        </div>
        <div class="col-md-3 box-statics">
             <div class="opthlive-features">
              <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Ophthalmologist/secure.png" alt="OpthLIVE HMIS" class="img-responsive">
            </div> 
             <span class="stat-text line-1">Secure</span>
             
        </div>   
        <div class="col-md-3 box-statics">
             <div class="opthlive-features">
              <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Ophthalmologist/anytime.png" alt="OpthLIVE HMIS" class="img-responsive">
            </div> 
             <span class="stat-text line-1">Anytime</span>
             
        </div>
        <div class="col-md-3 box-statics">
             <div class="opthlive-features">
              <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Ophthalmologist/anywere-access.png" alt="OpthLIVE HMIS" class="img-responsive">
            </div> 
             <span class="stat-text line-1">Anywhere access</span>
             
        </div>
        <div class="col-md-3 box-statics">
            <div class="opthlive-features">
              <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Ophthalmologist/high-redudancy.png" alt="OpthLIVE HMIS" class="img-responsive">
            </div> 
             <span class="stat-text line-1">High Redundancy</span>
             
        </div>
        <div class="col-md-3 box-statics">
             <div class="opthlive-features">
              <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Ophthalmologist/easy-to-use.png" alt="OpthLIVE HMIS" class="img-responsive">
            </div> 
             <span class="stat-text line-1">Easy to Use</span>

        </div>
        <div class="col-md-3 box-statics">
            <div class="opthlive-features">
              <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Ophthalmologist/seamless-interagtion.png" alt="OpthLIVE HMIS" class="img-responsive">
            </div> 
             <span class="stat-text line-1">Seamless Integration</span>
            
        </div>
        <div class="col-md-3 box-statics">
            <div class="opthlive-features">
              <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Ophthalmologist/modality-neutral.png" alt="OpthLIVE HMIS" class="img-responsive">
            </div> 
             <span class="stat-text line-1">Modality &amp; Vendor Neutral</span>
            
        </div>
        <div class="col-md-3 box-statics">
            <div class="opthlive-features">
              <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Ophthalmologist/multisite-management.png" alt="OpthLIVE HMIS" class="img-responsive">
            </div> 
             <span class="stat-text line-1">Multi Site Management</span>
            
        </div>
        <div class="col-md-3 box-statics">
            <div class="opthlive-features">
              <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Ophthalmologist/load-balancing.png" alt="OpthLIVE HMIS" class="img-responsive">
            </div> 
             <span class="stat-text line-1">Load Balancing</span>
            
        </div>
      </div>  <!--wrapper box-->
    </div>
</div>



<!--section3 ends here-->
<!--section 4-->

<div class="section-4" >
  <div class="container">
    <div class="ophtha-sextion1">
            <h2 class="section-title">Who can use RadLIVE ?</h2>
            <span class="border-green"></span>  
    </div>

   <div class="OpthLIVE-wrapper"> 
    <div class="col-md-4 ophtha-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/iRay.png" alt="OpthLIVE TELE" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Independent MRI, CT, US scan, CR &</h6>
        <h6 class="box-title">conventional X Ray centres</h6>
       </div><!--box content-->
    </div><!--col-md-4-->

    <div class="col-md-4 ophtha-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Radlive-Terelad.png" alt="OpthLIVE CLINICS" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Hospitals & Clinics with a</h6>
        <h6 class="box-title">radiology department</h6>
       </div><!--box content-->
    </div><!--col-md-4-->  

    <div class="col-md-4 ophtha-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-clouspacs.png" alt="OpthLIVE HMIS" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Third party integration with</h6>
        <h6 class="box-title">existing HIMS</h6>
       </div><!--box content-->
    </div><!--col-md-4--> 



    <p class="content-box">
        <span class="line-1">This cloud based complete practice management suite makes life easier for an optical practitioner or an ophthalmologist by saving cost and time.</span>
        <span class="line-2">In addition, it can be fully integrated with mydriatic and non-mydriatic retinal cameras, OCTs, B-Scans, & visual field instruments from</span>
        <span class="line-3">Topcon and other renowned global vendors.</span>
        
      </p>
  </div><!--wrapper-->

</div><!--container-->

</div>




<!--section 4 ends-->


<div class="clearfix"></div>


<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header popform">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Request for Live Demo</h4>
      </div>
      <div class="modal-body">
        <?php echo do_shortcode( '[contact-form-7 id="85" title="Live Demo"]' ); ?>
      </div>
      <div class="modal-footer">

      </div>
    </div>
  </div>
</div>
</div>
<!--modal-->


</div><!--container-fluid-->
<?php get_footer(); ?>
