<?php
/*
 * Template Name: Contact us page
 */
$deserve_options = get_option('deserve_theme_options');

get_header();
?>

<div class="container-fluid">
  <a data-toggle="modal" data-target="#myModal">
    <div class="float-demo" >

      <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/live-demo.png" alt="LIVE DEMO" >
      <span class="float-style">Request For Live Demo</span>
     </div> 
  </a>
    <!--section1 ends-->
<div class="section-1" >
  <div class="container-fluid">

    <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Contact-US/World-map.png" alt="Contactus-map" >
  </div>
</div> 



<!--section1 ends-->

<!--section 2-->

<div class="section-2" >
 <div class="container">
    <div class="ophtha-sextion1 opthalive-section">
            <h2 class="section-title">Contact Us</h2>
            <span class="border-green"></span>  

            <p class="content-box">
            <span class="line-1">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt</span>
            <span class="line-2">ut labore et dolore magna aliqua.</span>    
      </p>
    </div>

    <div class="location-wrapper">
      <div class="col-md-6 location-box wow slideInLeft" data-wow-offset="0" data-wow-duration="2s">
        <div class="locat-wrapper">
          <div class="location-image">
            <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Contact-US/singapore.png" alt="Contactus-map" >
           </div> 
           <span class="border-orange"></span>
          <div class="location-title">Singapore HQ</div>
          <div class="inner-box">
            <div class="innerbox-title">Pellucid Networks Pte. Ltd.</div>
            <div class="innerbox-content">
              <span class="boxline-1">Blk 71 #03-05, Ayer Rajah Crescent ,</span>    
              <span class="boxline-2">Singapore 139951</span>  
              <span class="boxline-3">Tel: +65 6776 7819</span>  
              <span class="boxline-4">Tel: +65 6776 7817</span>  
            </div>  
          </div><!--inner box-->  
        </div><!--wrapper-->
      </div>
      
      <div class="col-md-6 location-box wow slideInRight" data-wow-offset="0" data-wow-duration="2s">
        <div class="locat-wrapper">
        <div class="location-image">
            <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Contact-US/india.png" alt="Contactus-map" >
           </div> 
           <span class="border-orange"></span>
          <div class="location-title">India Operations</div>
          <div class="inner-box">
            <div class="innerbox-title">Pellucid Networks Pte. Ltd.</div>
            <div class="innerbox-content">
              <span class="boxline-1">Ground floor, Lotus Tower, 85 Anna Salai ,</span>    
              <span class="boxline-2">Guindy, Chennai 600032</span>  
              <span class="boxline-3">Tel: +9144 4217 1728</span>   
            </div>  
          </div><!--inner box--> 
        </div><!--wrapper-->
      </div>  

    </div><!--location wrapper-->  

 </div><!--container--> 
</div>

<!--section 2 ends-->
<!--section3-->
<div class="section-3" >
  <div class="container-fluid benefits-wrapper">
  
    <div class="ophtha-sextion1 opthalive-section">
            <h2 class="section-title">Get In Touch With Us</h2>
            <span class="border-green"></span>  

            <p class="content-box">
            <span class="line-1">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt</span>
            <span class="line-2">ut labore et dolore magna aliqua.</span>    
               
      </p>
    </div><!--opthalive section-->

    <div class="container form-section">
      <div class="col-md-7">
        <div class="contact-form">
         <?php echo do_shortcode( '[contact-form-7 id="74" title="Contact Us"]' ); ?>

        </div> 


      </div>  


      <div class="col-md-5">
         <div class="col-md-12 consulting-box"> 
          <div class="col-md-4 consulting-img">
            <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Contact-US/consulting-enquiry.png" alt="Contactus-map" >
          </div>
          <div class="col-md-8 consulting-content pad0">
            <div class="ulbox-content"> 
              <h6 class="ulbox-title">Consulting Enquiry</h6>
              <p class="ulcontent-smallbox">
              <span class="boxline-1"><a href="mailto:consulting@pellucidinc.com" target="_blank">consulting@pellucidinc.com</a></span>     
              </p>
             </div><!--box content-->
          </div>
         </div><!--col-md-12-->      

        <div class="col-md-12 consulting-box"> 
          <div class="col-md-4 consulting-img">
            <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Contact-US/product-enquiry.png" alt="Contactus-map" >
          </div>
          <div class="col-md-8 consulting-content pad0">
            <div class="ulbox-content"> 
              <h6 class="ulbox-title">Product Enquiry</h6>
              <p class="ulcontent-smallbox">
              <span class="boxline-1"><a href="mailto:enquiries@pellucidinc.com" target="_blank">enquiries@pellucidinc.com</a></span>     
              </p>
             </div><!--box content-->
          </div>
         </div><!--col-md-12-->

         <div class="col-md-12 consulting-box"> 
          <div class="col-md-4 consulting-img">
            <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/Contact-US/general-enquiry.png" alt="Contactus-map" >
          </div>
          <div class="col-md-8 consulting-content pad0">
            <div class="ulbox-content"> 
              <h6 class="ulbox-title">General and HR Enquiry</h6>
              <p class="ulcontent-smallbox">
              <span class="boxline-1"><a href="mailto:info@pellucidinc.com" target="_blank">info@pellucidinc.com</a></span>     
              </p>
             </div><!--box content-->
          </div>
         </div><!--col-md-12-->

      </div>  
    </div><!--container-->  
  </div><!--wrapper-->
</div> <!--SECTION3-->

<div class="clearfix"></div>

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header popform">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Request for Live Demo</h4>
      </div>
      <div class="modal-body">
        <?php echo do_shortcode( '[contact-form-7 id="85" title="Live Demo"]' ); ?>
      </div>
      <div class="modal-footer">

      </div>
    </div>
  </div>
</div>
</div>
<!--modal-->

</div><!--container-fluid-->
<?php get_footer(); ?>
