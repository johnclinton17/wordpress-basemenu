<?php
/*
 * Template Name: Legal page
 */
$deserve_options = get_option('deserve_theme_options');

get_header();
?>

<div class="container-fluid">
  <a data-toggle="modal" data-target="#myModal">
    <div class="float-demo" >

      <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/live-demo.png" alt="LIVE DEMO" >
      <span class="float-style">Request For Live Demo</span>
     </div> 
  </a>
    <!--section1 ends-->
<div class="section-1 background-height" >
    <div class="download-banner">
    <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/banner.jpg" alt="LIVE DEMO" >
  </div>   

</div> 
<!--section1 ends-->

<!--section 2-->

<div class="section-2">
  <div class="container" >
    

    <div class="tab-wrapper">

        <!-- Nav tabs -->
       <div class="tab-header col-md-12">   
        <ul class="nav nav-tabs" role="tablist">
          <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Terms of Use</a></li>
          <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Privacy Policy</a></li>
        </ul>
       </div>
        
        <!-- Tab panes -->
       <div class="tab-body col-md-12">
        <div class="tab-content">
          <div role="tabpanel" class="tab-pane fade in active" id="home">

              <h4 class="tab-title">Terms of Use</h4>

            <h5 class="tab-subtitle">Terms of Use</h5>
            <p class="tab-para">Pellucid Ptd Ltd.(“Pellucid”) is committed to protecting your privacy. Our policy is to collect no personally identifiable information about you when you visit our web site unless you affirmatively choose to make such information available to us. However, our web servers may recognize some non-personal information such as your Internet location (IP address).</br>We provide you the right and control over your personal information while visiting our web site. We acknowledge that personal information, such as your name, e-mail address, telephone number, etc. are kept private and confidential. At some point during your visit, you may be required to give that information for internal purposes. Accordingly, the information you provide is stored in a secure location and it is only accessible by designated staff of Pellucid.</p><br>

            <h5 class="tab-subtitle">Privacy Statement – Feedback Survey Data</h5>
            <p class="tab-para">Pellucid provides software as a service (SaaS) service for businesses conducting feedback collection using mobile devices and other collection methods. Following collection, the information is stored on Pellucid’s platform for analysis, these activities are primarily targeting customer and employee satisfaction issues, but may also include market, product, and service research, as well as other types of research. Survey data collected may be hosted and accessible on Pellucid‘s platform, or on our clients’ own hosting sites. Collected data may provide our clients with your Personal Information for the purpose of improving their operations and/or contacting you to follow up on your service experience, and/or the information you provided. Be aware that Pellucid’s clients have full access to the data, and therefore bear full responsibility for usage of that data. In such cases, please refer to the privacy policy of the Pellucid’s client who invited you to provide information and feedback.</p><br>

            <h5 class="tab-subtitle">Communications</h5><br>
            <h5 class="tab-subtitle">All communications with Pellucid are transmitted over SSL (HTTPS) for both access to the Insight Center as well as the API.</h5><br>

            <h5 class="tab-subtitle">Credit Card Security</h5>
            <p class="tab-para">We use third-party payment processors (the “Payment Processors”) to bill you through a payment account linked to your Account on the Services (your “Billing Account”) for use of the paid Services. The processing of payments will be subject to the terms, conditions and privacy policies of the Payment Processors in addition to this Agreement. We are not responsible for error by the Payment Processors. By choosing to use paid Services, you agree to pay us, through the Payment Processors, all charges at the prices then in effect for any use of such paid Services in accordance with the applicable payment terms and you authorize us, through the Payment Processors, to charge your chosen payment provider (your “Payment Method”). You agree to make payment using that selected Payment Method. We reserve the right to correct any errors or mistakes that it makes even if it has already requested or received payment.</p><br>

            <h5 class="tab-subtitle">Contacting Us</h5>
            <p class="tab-para">f you have any questions or suggestions about this privacy statement, the practices of this web site, or your interactions with this site, please write to us at info -at- pellucid.inc</p><br>

          </div>

          <div role="tabpanel" class="tab-pane fade" id="profile">

            <h4 class="tab-title">Privacy Policy</h4>

            <h5 class="tab-subtitle">Privacy Statement</h5>
            <p class="tab-para">Pellucid Ptd Ltd.(“Pellucid”) is committed to protecting your privacy. Our policy is to collect no personally identifiable information about you when you visit our web site unless you affirmatively choose to make such information available to us. However, our web servers may recognize some non-personal information such as your Internet location (IP address).</br>We provide you the right and control over your personal information while visiting our web site. We acknowledge that personal information, such as your name, e-mail address, telephone number, etc. are kept private and confidential. At some point during your visit, you may be required to give that information for internal purposes. Accordingly, the information you provide is stored in a secure location and it is only accessible by designated staff of Pellucid.</p><br>

            <h5 class="tab-subtitle">Privacy Statement – Feedback Survey Data</h5>
            <p class="tab-para">Pellucid provides software as a service (SaaS) service for businesses conducting feedback collection using mobile devices and other collection methods. Following collection, the information is stored on Pellucid’s platform for analysis, these activities are primarily targeting customer and employee satisfaction issues, but may also include market, product, and service research, as well as other types of research. Survey data collected may be hosted and accessible on Pellucid‘s platform, or on our clients’ own hosting sites. Collected data may provide our clients with your Personal Information for the purpose of improving their operations and/or contacting you to follow up on your service experience, and/or the information you provided. Be aware that Pellucid’s clients have full access to the data, and therefore bear full responsibility for usage of that data. In such cases, please refer to the privacy policy of the Pellucid’s client who invited you to provide information and feedback.</p><br>

            <h5 class="tab-subtitle">Communications</h5><br>
            <h5 class="tab-subtitle">All communications with Pellucid are transmitted over SSL (HTTPS) for both access to the Insight Center as well as the API.</h5><br>

            <h5 class="tab-subtitle">Credit Card Security</h5>
            <p class="tab-para">We use third-party payment processors (the “Payment Processors”) to bill you through a payment account linked to your Account on the Services (your “Billing Account”) for use of the paid Services. The processing of payments will be subject to the terms, conditions and privacy policies of the Payment Processors in addition to this Agreement. We are not responsible for error by the Payment Processors. By choosing to use paid Services, you agree to pay us, through the Payment Processors, all charges at the prices then in effect for any use of such paid Services in accordance with the applicable payment terms and you authorize us, through the Payment Processors, to charge your chosen payment provider (your “Payment Method”). You agree to make payment using that selected Payment Method. We reserve the right to correct any errors or mistakes that it makes even if it has already requested or received payment.</p><br>

            <h5 class="tab-subtitle">Contacting Us</h5>
            <p class="tab-para">f you have any questions or suggestions about this privacy statement, the practices of this web site, or your interactions with this site, please write to us at info -at- pellucid.inc</p><br>

          </div>
          
        </div>
       </div> 
</div>





  </div><!--container-->
</div>

<!--section 2 ends-->

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header popform">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Request for Live Demo</h4>
      </div>
      <div class="modal-body">
        <?php echo do_shortcode( '[contact-form-7 id="85" title="Live Demo"]' ); ?>
      </div>
      <div class="modal-footer">

      </div>
    </div>
  </div>
</div>
</div>
<!--modal-->
</div><!--container-fluid-->
<?php get_footer(); ?>
