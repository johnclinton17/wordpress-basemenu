<?php
/*
 * Template Name: RadLIVE TELERAD page
 */
$deserve_options = get_option('deserve_theme_options');

get_header();
?>

<div class="container-fluid">
  <a data-toggle="modal" data-target="#myModal">
    <div class="float-demo" >

      <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/live-demo.png" alt="LIVE DEMO" >
      <span class="float-style">Request For Live Demo</span>
     </div> 
  </a>
    <!--section1 ends-->
  <div class="section-1 background-height background-heightnew" >

      <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-TELERAD/Banner.png" alt="OpthLIVE HMIS" class="img-responsive">
      <div class="carousel-caption static-ban">
      <h3>Enhancing your operational dynamics</h3>   
      <button class="slider-but"><a href="<?php echo esc_url(home_url('')); ?>/contact-us">Contact us for More Info</a></button>
    </div>
</div>
<!--section1 ends-->

<!--section 2-->

<div class="section-2" >
  <div class="container">
    <div class="ophtha-sextion1 opthalive-section">
            <h2 class="section-title">RadLIVE TELERAD</h2>
            <span class="border-green"></span>  

            <p class="content-box">
            <span class="line-1">Teleradiology helps physicians to collaborate when they are not able to meet face to face. For instance, an emergency case at</span>
            <span class="line-2">a rural urgent care center can get a radiology consultation from a specialist urban radiologist and discuss the case </span>    
            <span class="line-3">telephonically while viewing his or her patient’s images.</span>    
      </p>
    </div>

   <div class="OpthLIVE-wrapper1 "> 
    <div class="col-md-3 ophtha-box opthLIve-box iray-box">
      <div class="opthlive-imagewrapper">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-TELERAD/minimal-software-installation.png" alt="OpthLIVE TELE" class="img-responsive">
      </div> 
       <div class="box-content"> 
        <h6 class="box-title">Minimal Capital Expenditure</h6>
        
       </div><!--box content-->
    </div><!--col-md-3-->

    <div class="col-md-3 ophtha-box opthLIve-box iray-box">
      <div class="opthlive-imagewrapper">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-TELERAD/pay-as-you-go.png" alt="OpthLIVE CLINICS" class="img-responsive">
      </div> 
       <div class="box-content"> 
        <h6 class="box-title">Pay as You Go</h6>
        
       </div><!--box content-->
    </div><!--col-md-3-->  

     <div class="col-md-3 ophtha-box opthLIve-box iray-box">
      <div class="opthlive-imagewrapper">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-TELERAD/minimal-capital-expenditure.png" alt="OpthLIVE HMIS" class="img-responsive">
      </div> 
       <div class="box-content"> 
        <h6 class="box-title">Minimal Software Installation</h6>
        
       </div><!--box content-->
    </div><!--col-md-3--> 

    <div class="col-md-3 ophtha-box opthLIve-box iray-box">
      <div class="opthlive-imagewrapper">
           <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-TELERAD/anytime.png" alt="OpthLIVE HMIS" class="img-responsive">
      </div>     
           <div class="box-content"> 
            <h6 class="box-title">Anytime</h6>
            
           </div><!--box content-->
        </div><!--col-md-3-->

        <div class="col-md-3 ophtha-box opthLIve-box iray-box">
      <div class="opthlive-imagewrapper">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-TELERAD/anywere-access.png" alt="OpthLIVE TELE" class="img-responsive">
      </div>
       <div class="box-content"> 
        <h6 class="box-title">Anywhere Access</h6>
        
       </div><!--box content-->
    </div><!--col-md-3-->

    <div class="col-md-3 ophtha-box opthLIve-box  iray-box">
      <div class="opthlive-imagewrapper">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-TELERAD/instant-access.png" alt="OpthLIVE CLINICS" class="img-responsive">
      </div> 
       <div class="box-content"> 
        <h6 class="box-title">Instant Start</h6>
        
       </div><!--box content-->
    </div><!--col-md-3-->  

     <div class="col-md-3 ophtha-box opthLIve-box iray-box">
      <div class="opthlive-imagewrapper">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-TELERAD/scalable.png" alt="OpthLIVE HMIS" class="img-responsive">
      </div> 
       <div class="box-content"> 
        <h6 class="box-title">Scalable</h6>
        
       </div><!--box content-->
    </div><!--col-md-3--> 
<div class="col-md-12 iray-wrapper">
    <p class="content-box">
            <span class="line-1">  iRay lets you to convert your X-ray films to diagnostic quality DICOM images with an advanced DICOM viewer and full PACS integration capabilities. iRay is </span>
            <span class="line-2">the most comprehensive and cost-effective alternative to expensive X-ray digitizers.</span>
            <span class="line-3">I-ray is available separately or as a part of the RadLIVE series.</span>
    </p>
</div>    
  </div><!--wrapper-->

</div><!--container-->

</div>

<!--section 2 ends-->
<!--section3-->
<div class="section-3" >
  <div class="container-fluid benefits-wrapper">
  <div class="container">
    
    <div class="ophtha-sextion1">
        <h2 class="section-title">Features</h2>
        <span class="border-green"></span>  
    </div>


    <div class="OPHTHALIVEWRAPPER wow slideInLeft" data-wow-offset="0" data-wow-duration="1.5s">
    
        <div class="col-md-3 ophtha-box irayfeture-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-TELERAD/usuability.png" alt="OpthLIVE TELE" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Usability</h6>
        <p class="content-smallbox">
           Works on Internet explorer, Firefox, Chrome. Role based access to radiologist, radiographer, referring physicians, Tele Radiology work flow co-ordinator (TWC)
        </p>
        
       </div><!--box content-->
    </div><!--col-md-4-->

        <div class="col-md-3 ophtha-box irayfeture-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-TELERAD/dashboard.png" alt="OpthLIVE TELE" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Dashboards</h6>
        <p class="content-smallbox">
           Real time Business intelligence dashboards for Total studies, completed studies, Pending studies, Bad studies, Duplicate Studies
        </p>
        
       </div><!--box content-->
    </div><!--col-md-4-->

       <div class="col-md-3 ophtha-box irayfeture-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-TELERAD/collaboration.png" alt="OpthLIVE TELE" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Collaboration</h6>
        <p class="content-smallbox">
             Active collaboration between radiologist, radiographer and  Transcriptionist. Commenting on individual patient studies.
        </p>
        
       </div><!--box content-->
    </div><!--col-md-4-->

       <div class="col-md-3 ophtha-box irayfeture-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-TELERAD/worklist.png" alt="OpthLIVE TELE" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Worklist</h6>
        <p class="content-smallbox">
           Graphical study status indication, Sort studies by patient name, DOB, Accession No. , Study date, study description, imaging centre name,  Modality, uploaded date.
        </p>
        
       </div><!--box content-->
    </div><!--col-md-4-->

    <div class="col-md-3 ophtha-box irayfeture-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-TELERAD/compression.png" alt="OpthLIVE TELE" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Compression</h6>
        <p class="content-smallbox">
           User defined compression stages - Lossless, Lossy Excellent, Lossy very Good, Lossy good, Lossy Medium, Lossy Fair. Jpeg/JPEG 2000 compression.
        </p>
        
       </div><!--box content-->
    </div><!--col-md-4-->

    <div class="col-md-3 ophtha-box irayfeture-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-TELERAD/reporting.png" alt="OpthLIVE TELE" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Reporting</h6>
        <p class="content-smallbox">
           Integrated online reporting engine, Structured reporting - Modality Type - Body type - Scan type - Normal template (or) Abnormal.
        </p>
        
       </div><!--box content-->
    </div><!--col-md-4-->

    <div class="col-md-3 ophtha-box irayfeture-box">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-TELERAD/clustering.png" alt="OpthLIVE TELE" class="img-responsive">
       
       <div class="box-content"> 
        <h6 class="box-title">Clustering</h6>
        <p class="content-smallbox">
           Multiple imaging centres can be hosted on single server, Single sign on access and single worklist for multiple sites.
        </p>
        
       </div><!--box content-->
    </div><!--col-md-4-->





  </div><!--content wrapper-->
  </div><!--container--> 
  </div><!--wrapper-->
</div> <!--SECTION3-->

<div class="clearfix"></div>

<!--section 4-->

<div class="section-4" >

<div id="myCarousel1" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel1" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel1" data-slide-to="1"></li>
    <li data-target="#myCarousel1" data-slide-to="2"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      
      <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-TELERAD/Dashboard-Slider.png" alt="OpthLIVE CLINICS" >
    </div>
    

    <div class="item">
       <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-TELERAD/END-OF-DAY-Slider.png" alt="OpthLIVE CLINICS" >
    </div>

    <div class="item">
     <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-TELERAD/Audit-trail-excel-Slider.png" alt="OpthLIVE CLINICS" >
    </div>

  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>


</div><!--section4-->


<div class="clearfix"></div>

<!--section6-->
<div class="section-6" >
<div class="conatiner-fluid cloudpacs-wrapper">
    <div class="ophtha-sextion1">
            <h2 class="section-title"></h2>
           
    </div> 

   <div class="container">
    <div class="center-image"> 
    <img src="<?php echo esc_url( get_template_directory_uri() );?>/images/RadLIVE-TELERAD/Infograph.png" alt="RadLIVE-TELERAD" class="img-responsive">
   </div> 
   </div>

 </div>  
</div> <!--SECTION3-->

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header popform">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Request for Live Demo</h4>
      </div>
      <div class="modal-body">
        <?php echo do_shortcode( '[contact-form-7 id="85" title="Live Demo"]' ); ?>
      </div>
      <div class="modal-footer">

      </div>
    </div>
  </div>
</div>
</div>
<!--modal-->

</div><!--container-fluid-->
<?php get_footer(); ?>
