<?php
/*
 * Header For Deserve Theme.
 */
  $deserve_options = get_option( 'deserve_theme_options' );
  
?><!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 7) & !(IE 8)]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width">
	
	
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<!--[if lt IE 9]>
	<script src="<?php echo get_template_directory_uri(); ?>/js/html5.js"></script>
	<![endif]-->
	<?php wp_head(); ?>
</head>



<header clas="nav-down">    
    
    
    <div class="menubar responsive-menubar">
      
    	<div class="deserve-container clearfix">
            <div class="col-md-2">
            	<div  class="site-logo">
									
        		<a href="<?php echo esc_url(home_url('/')); ?>"><img src="<?php echo esc_url( get_template_directory_uri() );?>/images/pellucid.jpg" class="img-responsive" /></a>
		
                    
                </div><!--site logo-->
            </div><!--col 2-->

            <div class="col-md-10">
               <div class="burgercontain">
    <span class="menu-text">Menu</span><div class="burger"> <div class="span"></div>  </div>
  </div>
<div class="nav-wrapper">
<h1 class="logo-right">
    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
      <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/image/logo.png"
        class="img-reponsive header-image"
        alt="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" 
      />
    </a>
  </h1><!-- logo -->

<nav id="site-navigation" class="main-navigation pushmenu-right" role="navigation" aria-label="<?php _e( 'Primary Menu', 'peoplefirst' ); ?>">
<?php if ( has_nav_menu( 'primary' ) || has_nav_menu( 'social' ) ) : ?>
  <?php if ( has_nav_menu( 'primary' ) ) : ?>
    <?php
      wp_nav_menu( array(
        'theme_location' => 'primary',
        'menu_class'     => 'primary-menu',
        'container_class' => 'list-menu',
        ) );
    ?>
    
  <?php endif;  
    endif; ?>
</nav><!-- .site-navigation -->
<nav id="site-socialnav">
<ul class="menu-socialicon">
      <li> <a href="https://www.facebook.com/PeopleFirstConsultants/" target="_blank"> <i class="fa fa-facebook"></i> </a></li>
      <li> <a href="https://www.linkedin.com/company/people-first-consultants-pvt-ltd?trk=nav_account_sub_nav_company_admin" target="_blank"> <i class="fa fa-linkedin"></i> </a></li>
      <li> <a href="http://www.slideshare.net/PeopleFirstLnD"  target="_blank"> <i class="fa fa-slideshare"></i> </a></li>
      <li> <a href="https://twitter.com/PeopleFirstTeam" target="_blank"> <i class="fa fa-twitter"></i>  </a></li>
    </ul>
  </nav>
</div><!-- .nav-wrapper -->
            </div><!--col 10-->
        </div><!--container-->
      </div><!--container fluid-->
    </div><!--menubar-->
    
</header>
<body <?php body_class(( array( "menu-push") )); ?> id="main-bodyk">
