<?php
/*
 * Header For Deserve Theme.
 */
  $deserve_options = get_option( 'deserve_theme_options' );
  
?><!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 7) & !(IE 8)]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width">
	
	
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<!--[if lt IE 9]>
	<script src="<?php echo get_template_directory_uri(); ?>/js/html5.js"></script>
	<![endif]-->
	<?php wp_head(); ?>
</head>


<main>
<header clas="nav-down">    
    
    
    <div class="menubar responsive-menubar">
      
    	<div class="deserve-container clearfix">
            <div class="col-md-2">
            	<div  class="site-logo">
									
        		<a href="<?php echo esc_url(home_url('/')); ?>"><img src="<?php echo esc_url( get_template_directory_uri() );?>/images/pellucid.jpg" class="img-responsive" /></a>
		
                 
                </div><!--site logo-->
            </div><!--col 2-->

            <div class="col-md-10">
                <div class="header-menu">             
                   
                  <a href="#cd-nav" class="cd-nav-trigger">
                   Menu<span><!-- used to create the menu icon --></span>
                   </a> <!-- .cd-nav-trigger -->         
                </div><!--header menu-->

            </div><!--col 10-->
        </div><!--container-->
      </div><!--container fluid-->
    </div><!--menubar-->
    
</header>


  <div class="cd-overlay"><!-- shadow layer visible when navigation is visible --></div>
<body <?php body_class(); ?>>
