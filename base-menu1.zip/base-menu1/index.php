<?php 
/*
 * Main Template File.
 */
get_header(); ?>

<section>
 
    <div class="deserve-container">      
      <div class="wrapper-margin"> 
        <div class="col-md-9   dblog">        
            
                  <?php while ( have_posts() ) : the_post(); ?>
            
            <div class="col-md-6">
            <div class=" ophtha-box blogbox">
            	<a href="<?php echo get_permalink(); ?>">
     				<?php the_post_thumbnail( 'small-featured' ); ?>                               		
				</a> 
                <div class="post-data">
					
					<a href="<?php echo get_permalink(); ?>" class=" fronttitle-blog"><?php the_title(); ?></a>      
                </div>
                                          
                   <p class="content-smallbox front-blog">
        				<?php the_excerpt(10); ?>
  				   </p>          
            </div>

       	</div>
         <?php endwhile;  ?>     

</div>
           
            
            <div class="gallery-pagination blog-pagination">
                <ul>
						
						<?php if (function_exists('the_posts_pagination')) 
						{ ?>
								

						<li class="link_pagination" >
								<?php deserve_pagination(); ?>
						</li>
					
					<?php } else { ?>
							<li class="link_pagination"><?php previous_posts_link( '<<' ); ?> </li>

							<li class="link_pagination"><?php next_posts_link( '>>' ); ?> </li>		
					 
					
					<?php } ?>
					 
				
                </ul>
            </div>
         
        </div>
      <div class="col-md-3 sidebar-wrapper margin-bottom"> 
    <?php get_sidebar(); ?> 
    </div>
    </div><!--wrapper-->
    </div>

</section>


<?php get_footer(); ?>
