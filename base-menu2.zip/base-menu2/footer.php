<?php
/**
 * Footer For Deserve Theme.
 */
?>

<?php  $deserve_options = get_option( 'deserve_theme_options' ); ?>

<footer class="main_footer footer-menu">
  <div class="container-fluid foot-back">
    <div class="container">
       <div class="col-md-12 foot-center">
          <span class="text1">Ready to Move Pellucid</span>
          <span class="text2">Explore More on Today ?</span>
          <button class="foot-but1"><a href="<?php echo esc_url(home_url('')); ?>/contact-us">Contact us for More Info</a></button>

       </div><!--col-md-12-->
    </div><!--container-->
    </div><!--container fluid-->  

    <!--footer list starts here--> 
    <div class="container foot-margin">
      <div class="col-md-2">
      <h6 class="foot-header">About Us</h6>
          <ul class="foot-list">
            <li><a href="<?php echo esc_url(home_url('')); ?>/about-us">Why Pellucid ?</a></li>
            <li><a href="<?php echo esc_url(home_url('')); ?>/about-us">Core Belif</a></li>
            <li><a href="<?php echo esc_url(home_url('')); ?>/about-us">Timeline</a></li>
            <li><a href="<?php echo esc_url(home_url('')); ?>/about-us">Team</a></li>
            <li><a href="<?php echo esc_url(home_url('')); ?>/about-us">BOD &amp; Investors</a></li>
          </ul>  
      </div>
      <div class="col-md-2">
      <h6 class="foot-header">Ophthalmology Simplified</h6>
          <ul class="foot-list">
            <li><a href="<?php echo esc_url(home_url('')); ?>/opthlive-tele">Opthlive TELE</a></li>
            <li><a href="<?php echo esc_url(home_url('')); ?>/opthlive-clinics">Opthlive CLINIC</a></li>
            <li><a href="<?php echo esc_url(home_url('')); ?>/opthlive-hmis">Opthlive HMIS</a></li>
          </ul> 
      </div>
      <div class="col-md-2">
      <h6 class="foot-header">Radiology Simplified</h6>
          <ul class="foot-list">
            <li><a href="<?php echo esc_url(home_url('')); ?>/iray/">iRay</a></li>
            <li><a href="<?php echo esc_url(home_url('')); ?>/radlive-telerad">RadLIVE Telerad</a></li>
            <li><a href="<?php echo esc_url(home_url('')); ?>/radlive-cloudpacs">RadLIVE CloudPACS</a></li>
            
          </ul> 
      </div>
      <div class="col-md-2">
      <h6 class="foot-header">Services</h6>
          <ul class="foot-list">
            <li><a href="<?php echo esc_url(home_url('')); ?>/radlive-cloudpacs/">Eye Screening Platform</a></li>
            <li><a href="#">Trusted Reads</a></li>
            <li><a href="#">Consulting</a></li>
          </ul> 
      </div>
      <div class="col-md-2">
      <h6 class="foot-header">More</h6>
          <ul class="foot-list">
            <li><a href="">Careers</a></li>
            <li><a href="">Newsroom</a></li>
            <li><a href="">CSR Initiatives</a></li>
            <li><a href="<?php echo esc_url(home_url('')); ?>/legal">Legal</a></li>
          </ul> 
      </div>
      <div class="col-md-2">
      <h6 class="foot-header">Be Social</h6>
          <ul class="foot-list-social">
            <li><a href="<?php echo esc_url(home_url('')); ?>/contact-us"><span class="facebook"></span></a></li>
            <li><a href="<?php echo esc_url(home_url('')); ?>/contact-us"><span class="pintrest"></span></a></li>
            <li><a href="<?php echo esc_url(home_url('')); ?>/contact-us"><span class="linkedin"></span></a></li>
            <li><a href="<?php echo esc_url(home_url('')); ?>/contact-us"><span class="youtube"></span></a></li>
          </ul> 
    </div>  
    </div><!--container-->
   <!--footer list ends here-->
   <!--footer bottom-->
   <div class="container-fluid foot-bottom">
   <div class="container">
    <div class="col-md-6 foot-align">
       <span class="copyrights">All rights reserved.&copy; 2016.Pellucid</span>        
    </div>
    
    <div class="col-md-6 foot-align">
      <span class="digitalexperience">User Experience by <a  class="rilly" href="http://www.rillusion.com/" target="_blank">Rillusion</a></span>
    </div>
    </div><!--conatiner-->
  </div><!--container fluid-->
  <!--footer bottom-->   
</footer>







<?php wp_footer(); ?>
<!-- Menu Push action for mobile-->

<script type="text/javascript">

  jQuery(document).ready(function() {

    $menuLeft = $('.pushmenu-left');

    $nav_list = $('#nav-toggle');

    $nav_list.click(function() {

      $(this).toggleClass('active');

      $('.pushmenu-push').toggleClass('pushmenu-push-toright');

      $menuLeft.toggleClass('pushmenu-open');

    });

  });

</script>
</body>
</html>
