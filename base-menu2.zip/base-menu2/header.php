<?php
/*
 * Header For Deserve Theme.
 */
  $deserve_options = get_option( 'deserve_theme_options' );
  
?><!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 7) & !(IE 8)]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width">
	
	
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<!--[if lt IE 9]>
	<script src="<?php echo get_template_directory_uri(); ?>/js/html5.js"></script>
	<![endif]-->
	<?php wp_head(); ?>
</head>




<body <?php body_class(( array( "pushmenu-push") )); ?>>





<div id="page" class="site">



<header class="header-navigation">

<h1 class="logo"> 

      <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">

        <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/footer-logo.png"

          class="img-reponsive header-image"

          alt="Rillusion | Digital Design Agency for Startups"

        />

      </a>

    </h1>

  <nav class="pushmenu pushmenu-left">

    



    <div class="main-navigation">

    <!-- menu icon-->

   

    <!-- menu icon end -->

     <?php if ( has_nav_menu( 'primary' ) || has_nav_menu( 'social' ) ) : ?>

        

          <?php if ( has_nav_menu( 'primary' ) ) : ?>

            <nav id="site-navigation" class="main-navigation" role="navigation" aria-label="<?php _e( 'Primary Menu', 'flicks' ); ?>">

              <?php

                wp_nav_menu( array(

                  'theme_location' => 'primary',

                  'menu_class'     => 'primary-menu',

                 ) );

              ?>

            </nav><!-- .main-navigation -->

          <?php endif; ?>

        

      <?php endif; ?>

    </div>

  </nav>

   <a id="nav-toggle" href="#"><span></span></a>

</header>
  <div id="content" class="site-content">